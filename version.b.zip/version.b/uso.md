# Instrucciones de Uso

## Instalación de Dependencias
Ejecuta el siguiente comando para instalar todas las dependencias del proyecto:
```
npm install
```

## Encender los Servidores
Para iniciar el servidor de desarrollo (que incluye tanto el backend como el frontend):
```
npm run dev
```

Esto iniciará el servidor en el puerto predeterminado (generalmente 3000 o el configurado en server.ts). Abre tu navegador en `http://localhost:3000` para acceder a la aplicación.

## Construir para Producción
Para construir la aplicación para producción:
```
npm run build
```

## Vista Previa de Producción
Después de construir, para ver la versión de producción localmente:
```
npm run preview
```

## Limpieza
Para limpiar los archivos de construcción:
```
npm run clean
```

## Notas Adicionales
- Asegúrate de tener Node.js instalado (versión recomendada: 18+).
- Si usas Firebase, configura tus credenciales en un archivo `.env` usando las variables `VITE_FIREBASE_*` definidas en `.env.example`.
- La aplicación es una PWA, así que puedes instalarla como app en dispositivos compatibles.
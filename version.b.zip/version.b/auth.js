import './src/legacy/auth.ts';

import './src/legacy/script.ts';

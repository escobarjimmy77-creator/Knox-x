# Guía de Depuración: Sistema de Usernames Únicos

## Problema Reportado
En registro o cambio de usuario, aparecía: "Usuario ya está en uso" para TODOS los usuarios, incluso los no existentes.

## Solución Aplicada

### 1. **Mejoras en la Verificación**
- ✅ Sistema separa 3 estados: disponible, en uso, error de conexión
- ✅ Función `getUsernameInfo()` devuelve información detallada
- ✅ Mejor logging para debugging en la consola del navegador

### 2. **Almacenamiento en Firebase**
Los usernames se guardan en: `users/cerberusai-87db2 → usernames/`

**Estructura:**
```
usernames/
  ├── nombreusuario1/  → {uid: "user-id-123", reservedAt: 1234567890}
  ├── nombreusuario2/  → {uid: "user-id-456", reservedAt: 1234567890}
  └── ...
```

**Normalización ("username" → "nombreusuario"):**
- Minúsculas
- Espacios → guiones bajos
- Caracteres especiales removidos
- Solo letras, números, guiones, puntos
- 3-32 caracteres válidos

### 3. **Flujo de Registro**
```
1. Usuario ingresa nombre
   ↓
2. Validar que tiene 3-32 caracteres válidos
   ↓
3. Obtener info de Firebase: ¿existe?
   - Sí → Error: "Ya está en uso"
   - No → Continuar
   - Error de conexión → Error: "Revisa tu conexión"
   ↓
4. Crear cuenta en Firebase Auth
   ↓
5. Reservar nombre en base de datos
   ↓
6. Enviar email de verificación
```

## Cómo Verificar qué Está Pasando

### Opción 1: Consola del Navegador (Recomendado)
1. Abre el navegador → F12 (DevTools)
2. Pestaña Console
3. Intenta registrarte o cambiar username
4. Busca logs como:
   ```
   [Auth] getUsernameInfo("miusuario" → "miusuario"): exists=true, uid=user-id-123, isOwner=false
   [Auth] registerWithEmail: creando usuario con nombre miusario
   [Auth] reserveUsername: registrar "miusuario" para UID user-id-123
   ```

**Lo que significan:**
- `exists=true` → Username ya tomado
- `exists=false` → Username disponible
- `uid=null` → Username no existe
- `isOwner=true` → Es el usuario actual (puede reutilizar)
- Errores en consola = problema de conexión

### Opción 2: Firebase Console
1. Abre [Firebase Console](https://console.firebase.google.com/)
2. Proyecto: `cerberusai-87db2`
3. Realtime Database
4. Ve a `usernames/`
5. Verifica qué usernames están registrados
6. Cada uno debería tener:
   - Clave: nombreusuariónormalizado
   - Valor: `{uid: "...", reservedAt: ...}`

### Opción 3: Limpiar Usernames Duplicados
Si hay problemas de usernames "fantasma" o duplicados:

```javascript
// En Firebase Console → Realtime Database → Rules
// (Si tienes admin access)
// Puedes eliminar manualmente usernames problemáticos
// o usar el script de limpieza (ver abajo)
```

## Script de Verificación en Consola

Copia y pega en la consola del navegador para diagnosticar:

```javascript
// 1. Verificar si Firebase Auth está correcto
console.log('Auth actual:', window.AuthManager?.currentUser?.());
console.log('UID actual:', window.AuthHelpers?.currentUid?.());
console.log('Username actual:', window.AuthHelpers?.currentUsername?.());

// 2. Probar verificación de un username
const testUsername = 'prueba123';
window.AuthHelpers?.getUsernameInfo?.(testUsername).then(info => {
  console.log(`Username "${testUsername}" info:`, info);
  if (info?.exists) {
    console.log('  → Este nombre YA está en uso por UID:', info.uid);
  } else if (info?.exists === false) {
    console.log('  → Este nombre está DISPONIBLE');
  } else {
    console.log('  → No se pudo verificar (error de conexión)');
  }
});

// 3. Ver el nombre normalizado
const username = 'Mi Usuario 123';
console.log(`"${username}" se normaliza a:`, 
  String(username || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '_')
    .replace(/[.#$/\[\]\/]/g, '')
    .replace(/[^a-z0-9_\-\.]/g, '')
    .replace(/^[_\-.]+|[_\-.]+$/g, '')
);
```

## Signos de Que Todo es Correcto

✅ Al registrarse:
- Aparece "Un momento..." en el botón
- Luego aparece pantalla de verificación de email
- Sin errores en consola

✅ Al cambiar username:
- Se verifica disponibilidad primero
- Si falla la conexión, dice "Revisa tu conexión"
- Si está en uso, dice "Ese nombre ya está en uso"
- Si está disponible, se guarda

## Signos de Que Hay un Problema  

❌ Todas las pruebas de username dicen "Ya está en uso"
→ Check: Firebase RTDB conexión rota
→ Solución: Verifica que la DB URL sea correcta

❌ Consola muestra `error: "usernames" is null`
→ Check: La ruta `usernames/` no existe en la DB
→ Solución: Crea manualmente la ruta en Firebase Console

❌ El cambio de username "funciona" pero no se guarda
→ Check: Permisos de Firebase RTDB
→ Solución: Revisa las security rules en Firebase

## Cambios de Código

### Archivos Modificados:
1. **src/legacy/auth.ts**
   - ✅ `getUsernameInfo()` - Nueva función con info detallada
   - ✅ `checkUsernameAvailable()` - Devuelve true/false/null más claramente
   - ✅ `reserveUsername()` - Devuelve boolean, mejor logging
   - ✅ `_isValidUsername()` - Valida formato del username
   - ✅ `registerWithEmail()` - Mejor manejo de errores
   - ✅ `AuthHelpers` - Exporta `getUsernameInfo`

### Lo Que Cambió:
```diff
// Antes (ambiguo):
- checkUsernameAvailable() devolvía true/false/false
- Si error de conexión → false (igual que "en uso")
  
// Ahora (claro):
+ checkUsernameAvailable() devuelve true/"disponible"/false/"en uso"/null/"error"
+ getUsernameInfo() devuelve {exists, uid, isOwner} o null
+ Registrados en logs del navegador con timestamps
```

## Próximos Pasos (Opcional)

- [ ] Agregar "sugerencias de username disponibles"
- [ ] Agregar contador de intentos fallidos
- [ ] Agregar blacklist de usernames reservados (admin, support, etc.)
- [ ] Sincronizar usernames con perfil de usuario

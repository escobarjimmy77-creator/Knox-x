import './src/legacy/user-sync.ts';

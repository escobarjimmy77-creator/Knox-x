import './src/legacy/info-table.ts';

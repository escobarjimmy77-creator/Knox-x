# 🐛 Reporte de Bug: Configuraciones que no persisten

## Problema
Cuando activas/desactivas configuraciones (modo oscuro, color de acento, etc.) y reiniciar/recarga la app, vuelven a la configuración anterior.

**Ejemplo:**
- ✅ Activar modo oscuro → se guarda
- ❌ Reiniciar app → vuelve a modo claro

---

## Causa Raíz: Desincronización Local ↔ Firebase

### El flujo problemático:

```
Usuario cambia tema oscuro
    ↓
script.ts guarda SOLO en localStorage
    ↓
Usuario reinicia app / recarga
    ↓
auth.ts listener dispara: onAuthStateChanged()
    ↓
loadPreferences(uid) obtiene datos VIEJOS/VACÍOS de Firebase
    ↓
applyPreferences() SOBRESCRIBE localStorage con valores viejos de Firebase
    ↓
❌ Modo oscuro vuelve a ser claro
```

### Archivos implicados:
- **[src/legacy/script.ts](src/legacy/script.ts#L3587-L3621)** - Guarda cambios solo en localStorage
- **[src/legacy/auth.ts](src/legacy/auth.ts#L73-L91)** - Carga preferencias de Firebase (desactualizado)
- **[src/legacy/user-sync.ts](src/legacy/user-sync.ts)** - Sincronización de datos (no incluye preferencias)

---

## Solución: Sincronizar Cambios con Firebase

### Paso 1: Agregar función helper en auth.ts

Después de `loadPreferences()` (alrededor de línea 91), agrega:

```javascript
async function updatePreferencesLocal(key, value) {
    // Guardar en localStorage SIEMPRE
    localStorage.setItem(key, value);
    
    // Si hay usuario autenticado, guardar también en Firebase
    if (_currentUser) {
        try {
            await savePreferences(_currentUser.uid);
        } catch (error) {
            console.warn('[Auth] updatePreferencesLocal sync failed:', error?.message);
        }
    }
}

// Exportar para que script.js pueda usarlo
window.updatePreferencesLocal = updatePreferencesLocal;
```

---

### Paso 2: Modificar listeners en script.ts

**En Settings.setup(), reemplaza estos bloques:**

#### Dark Mode Toggle (línea ~3587-3621)
```javascript
// ❌ ANTES (línea 3620-3621)
localStorage.setItem("theme", theme);

// ✅ DESPUÉS
await window.updatePreferencesLocal?.("theme", theme);
```

Código completo corregido:
```javascript
darkToggle.addEventListener("change", async () => {
    const theme = darkToggle.checked ? "dark" : "light";
    this.applyTheme(theme);
    await window.updatePreferencesLocal?.("theme", theme);
    if (darkRowSub) darkRowSub.textContent = darkToggle.checked ? "Tema oscuro activo" : "Tema claro activo";
    showToast(darkToggle.checked ? "Modo oscuro activado" : "Modo claro activado");
});
```

#### AI Personalization Toggle  (línea ~3614-3629)
```javascript
// ❌ ANTES
localStorage.setItem("ai_personalization", aiToggle.checked ? "on" : "off");

// ✅ DESPUÉS
await window.updatePreferencesLocal?.("ai_personalization", 
    aiToggle.checked ? "on" : "off");
```

#### AI Catalog Toggle (línea ~3632-3648)
```javascript
// ❌ ANTES
localStorage.setItem("ai_catalog_only", catToggle.checked ? "on" : "off");

// ✅ DESPUÉS
await window.updatePreferencesLocal?.("ai_catalog_only", 
    catToggle.checked ? "on" : "off");
```

#### Accent Color (línea ~3409)
```javascript
// ❌ ANTES
localStorage.setItem("accent_color", color);

// ✅ DESPUÉS
await window.updatePreferencesLocal?.("accent_color", color);
```

#### Card Size (línea ~3417)
```javascript
// ❌ ANTES
localStorage.setItem("card_size", size);

// ✅ DESPUÉS
await window.updatePreferencesLocal?.("card_size", size);
```

---

### Paso 3: También sincronizar cambios de perfil en auth.ts

En la función que actualiza perfil (línea ~358-365), después de guardar en localStorage, llama:
```javascript
await savePreferences(_currentUser.uid);
```

---

## Verificación

Después de aplicar los cambios:
1. ✅ Activa modo oscuro
2. ✅ Abre Developer Tools → Console → verifica `localStorage.getItem('theme')`
3. ✅ Recarga la página (F5)
4. ✅ Verifica que el modo oscuro persista
5. ✅ Abre DevTools → Network → filtra "preferences" para ver la petición a Firebase

---

## Posibles Causas Adicionales (Verificar)

1. **Firebase rules restrictivas**: ¿Las reglas de Firebase permiten escribir en `users/{uid}/preferences`?
2. **Service Worker cache**: El `sw.js` podría estar cacheando respuestas viejas
3. **Timing issue**: Los cambios se guardan muy rápido y Firebase no sincroniza a tiempo

### Para verificar Service Worker:
```bash
# En DevTools Console:
navigator.serviceWorker.getRegistrations().then(regs => 
    regs.forEach(r => r.unregister())
);
```

---

## Resumen Final

| Tipo | Antes | Después |
|------|-------|---------|
| Modo oscuro + recarga | ❌ Vuelta a claro | ✅ Persiste |
| Cambios de color | ❌ Se pierden | ✅ Se guardan |
| Card size | ❌ Vuelve a normal | ✅ Se mantiene |
| **Sincronización** | Solo localStorage | localStorage + Firebase |


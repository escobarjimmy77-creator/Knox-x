# Guía de Verificación - Fullscreen del Reproductor

## 🧪 Testing Checklist

### 1. **Fullscreen en Desktop (Chrome, Firefox, Safari, Edge)**

- [ ] Hacer clic en botón fullscreen
- [ ] Verificar que:
  - [ ] El video ocupa 100% del ancho y alto
  - [ ] No hay barras negras innecesarias
  - [ ] El video NO se distorsiona
  - [ ] La barra de controles (peek bar) aparece al tocar
  - [ ] Los botones (exit, prev, next) funcionan
  - [ ] Presionar ESC cierra fullscreen correctamente

### 2. **Fullscreen en Android Chrome/Firefox**

- [ ] Abrir en móvil horizontal (landscape)
- [ ] Tocar botón fullscreen
- [ ] Verificar:
  - [ ] La pantalla se pone en true fullscreen (100vw x 100vh)
  - [ ] El video se ve correctamente sin deformaciones
  - [ ] Peek bar sale desde abajo e la barra de controles
  - [ ] Los botones (exit, prev/next ep) son tocables
  - [ ] System UI se oculta (si es PWA)
  - [ ] Puede salir con botón exit o back
  - [ ] Landscape se mantiene bloqueada
  - [ ] Rotación manual a portrait: maneja correctamente

### 3. **Fullscreen en iOS Safari**

- [ ] Usar iPhone en horizontal
- [ ] Tocar botón fullscreen
- [ ] Verificar:
  - [ ] Fullscreen se activa (aunque iOS tiene limitaciones)
  - [ ] Video está centrado
  - [ ] Safe area (notch) se respeta
  - [ ] Control deslizable aparece
  - [ ] Sin distorsión de video
  - [ ] Performance fluido

### 4. **Controladores en Fullscreen**

- [ ] Peek bar slide-up desde abajo
  - [ ] Botón exit: Cierra fullscreen
  - [ ] Botón prev: Episodio anterior
  - [ ] Botón next: Episodio siguiente
  - [ ] Info: Muestra título y número de episodio
- [ ] Auto-hide después de 3.2 segundos
- [ ] Tap en video reveal controles nuevamente

### 5. **Aspecto Ratio y Centering**

- [ ] 16:9 video en fullscreen landscape: Centrado perfecto
- [ ] No hay "letterboxing" incorrecto
- [ ] No hay "pillarboxing" extraño
- [ ] Video no está estirado
- [ ] Video no está comprimido

### 6. **Safe Areas (Notches, Chins)**

- [ ] iPhone 13/14/15 Pro con notch:
  - [ ] Los controles no quedan debajo del notch
  - [ ] Peek bar respeta safe-area-bottom
- [ ] Samsung con barra de navegación:
  - [ ] El video se ajusta sin sobrepasar
  - [ ] Peek bar respeta márgenes

### 7. **Transiciones y Animaciones**

- [ ] Entering fullscreen: Transición suave
- [ ] Exiting fullscreen: Transición suave
- [ ] Peek bar: Slide-up smooth
- [ ] No hay "flicker" o parpadeos
- [ ] No hay cambios abruptos de layout

### 8. **Keyboard/Input**

- [ ] Desktop: ESC cierra fullscreen
- [ ] Desktop: F11 no interfiere
- [ ] Mobile: Back button cierra fullscreen
- [ ] Mobile: Orientación automática se respeta

### 9. **Performance**

- [ ] Sin lag al entrar fullscreen
- [ ] Sin jank al interactuar con controles
- [ ] Tap response rápido
- [ ] Suave a 60fps (si el video lo permite)

### 10. **Errores y Edge Cases**

- [ ] Si fullscreen no es soportado: Fallback graceful
- [ ] Si orientation.lock no funciona: Sin crash
- [ ] Si exitFullscreen falla: Se maneja correctamente
- [ ] Múltiples fullscreen requests: Sin problemas
- [ ] Cambio rápido de episodio en fullscreen: Sin issues

## 🔍 Verificación de Código

### CSS Checks
```bash
# Verificar que fullscreen styles están presentes
grep -c "player-overlay:fullscreen" style.css  # Debe ser > 0

# Verificar media queries
grep -c "@media (orientation: landscape)" style.css  # Debe ser > 0

# Verificar safe-area support
grep -c "env(safe-area" style.css  # Debe ser > 0
```

### JavaScript Checks
```bash
# Verificar que nuevas funciones existen
grep -c "_requestFullscreen" src/legacy/script.ts  # Debe ser > 0
grep -c "_setupFullscreenListener" src/legacy/script.ts  # Debe ser > 0
grep -c "_lockLandscape" src/legacy/script.ts  # Debe ser > 0
grep -c "_exitFullscreen" src/legacy/script.ts  # Debe ser > 0

# Verificar compilación
npm run lint  # Debe pasar sin errores
```

## 📊 Resultado Esperado

Después de estas verificaciones, deberías ver:

✅ **Fullscreen limpio**: Sin elementos superpuestos
✅ **Video centrado**: Sin deformaciones
✅ **Landscape fluido**: Especialmente en móvil
✅ **Controles accesibles**: Peek bar interactivo
✅ **Compatible**: Android, iOS, Desktop
✅ **Performance**: Sin lag ni jank
✅ **tipo YouTube**: UX limpia y profesional

## 🚨 Problemas Conocidos y Soluciones

### Problema: "Video se distorsiona en landscape"
**Solución**: Verificar `object-fit: contain` en #player-iframe

### Problema: "Peek bar no aparece"
**Solución**: Verificar que .player-cinema-peek tiene `z-index: 2147483646`

### Problema: "Fullscreen no funciona en iOS"
**Solución**: iOS tiene limitaciones nativas, pero el contenedor debe estar visible

### Problema: "Notch cubre controles"
**Solución**: Verificar `env(safe-area-inset-bottom)` en .player-cinema-peek

### Problema: "Se ve bien pero con lag"
**Solución**: Verificar `will-change: transform` en .player-overlay

## 📝 Notas de Desarrollo

- Los z-index 2147483647 es el máximo posible en JavaScript
- Safe-area-inset funciona en iOS 11.2+ y navegadores soportados
- Fullscreen API tiene diferentes prefixes: webkit-, moz-, ms-
- Landscape lock solo funciona en PWA instalada en Android
- object-fit: contain es mejor que cover para videos (no crop)

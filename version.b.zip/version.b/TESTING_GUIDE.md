# ✅ Guía de Prueba: Bug Fix Configuraciones que no Persisten

## 🔧 Cambios Realizados

Se han actualizado los archivos:
- **[src/legacy/auth.ts](src/legacy/auth.ts#L93-L115)** - Agregada función `updatePreferencesLocal()`
- **[src/legacy/script.ts](src/legacy/script.ts)** - Actualizados 5 listeners para sincronizar con Firebase:
  - Accent Color (línea ~3409)
  - Card Size (línea ~3417)
  - AI Personalization Toggle (línea ~3563)
  - AI Catalog Toggle (línea ~3577)
  - Dark Mode Toggle (línea ~3591)

---

## 📋 Plan de Pruebas

### ✅ Test 1: Modo Oscuro (Caso Principal)

**Sin autenticar:**
```
1. Abre DevTools (F12)
2. Consola: localStorage.getItem('theme')
   → Debería ser 'dark' o null

3. Voy a Settings → Activo Modo Oscuro
4. ✅ Interface cambia a oscuro
5. Consola: localStorage.getItem('theme')
   → Debería ser 'dark'

6. Recarga la página (F5)
7. ✅ Debería mantener modo oscuro

8. Consola: localStorage.getItem('theme')
   → Debería seguir siendo 'dark'
```

**Autenticado:**
```
1. Inicia sesión con tu cuenta
2. Ve a Settings → Activa Modo Oscuro
3. Abre DevTools → Pestaña Network
   → Deberías ver una petición a Firebase: "preferences"
   → Status: 200 OK

4. Consola: localStorage.getItem('theme')
   → Debería ser 'dark'

5. Recarga página (F5)
6. ✅ Modo oscuro debería persistir

7. Cierra sesión y abre nuevamente
8. ✅ Debería cargar con modo oscuro desde Firebase
```

---

### ✅ Test 2: Color de Acento

```
1. Settings → selecciona un color diferente (ej: Morado)
2. Consola: localStorage.getItem('accent_color')
   → Debería ser '#8b5cf6' (o el color seleccionado)

3. Recarga página
4. ✅ Color debería persistir

5. Si estás autenticado, el Network tab debería mostrar sync a Firebase
```

---

### ✅ Test 3: Tamaño de Tarjetas

```
1. Settings → selecciona tamaño "Grande"
2. Consola: localStorage.getItem('card_size')
   → Debería ser 'large'

3. Recarga página
4. ✅ Tamaño debería mantenerse

5. Si estás autenticado, verificar Network → Firebase sync
```

---

### ✅ Test 4: Toggles de IA

```
1. Settings → Desactiva "Personalización de IA"
2. Consola: localStorage.getItem('ai_personalization')
   → Debería ser 'off'

3. Recarga página
4. ✅ Debería mantenerse desactivado

5. Hacer lo mismo con "Catálogo solo títulos disponibles"
```

---

## 🔍 Verificación en DevTools

### Console Tab
```javascript
// Verificar que localStorage se actualiza
localStorage.getItem('theme')  // 'dark'
localStorage.getItem('accent_color')  // '#6366f1'
localStorage.getItem('card_size')  // 'normal'

// Verificar que la función existe
typeof window.updatePreferencesLocal  // 'function'
```

### Network Tab
**Si estás autenticado, deberías ver:**
- Petición POST a: `https://your-firebase-db/users/{uid}/preferences.json`
- Status: `200 OK` ✅
- Payload: JSON con tema, color, etc.

**Si NO ves la petición:**
- ❌ Firebase rules podrían estar bloqueando
- ❌ Usuario no está autenticado correctamente
- ❌ Error en la consola (revisar errores)

---

## 🐛 Si Algo No Funciona

### Error 1: "No persisten los cambios"
```javascript
// En Console, verifica:
localStorage.getItem('theme')

// Si no se actualiza:
// → Problema en event listener (revisar script.ts)
```

### Error 2: "Firebase no sincroniza"
```javascript
// Verifica autenticación:
firebase.auth().currentUser  // Debería mostrar tu usuario

// Verifica Network:
// DevTools → Network → filtra por "preferences"
// Si no ves petición → updatePreferencesLocal() no se está llamando
```

### Error 3: "Firebase rules error"
```
Permiso denegado en Firebase RTDB
→ Las reglas podrían estar restrictivas
→ Verifica: users/{uid}/preferences en Firebase Console
```

---

## 📊 Checklist de Verificación Final

- [ ] Modo oscuro persiste after reload (sin autenticar)
- [ ] Modo oscuro persiste after reload (autenticado)
- [ ] Color de acento se guarda correctamente
- [ ] Tamaño de tarjetas se mantiene
- [ ] Toggles de IA persisten
- [ ] Si autenticado: Firebase sync aparece en Network
- [ ] Console muestra logs: "[Auth] Preferences synced to Firebase"
- [ ] No hay errores en Console

---

## 🚀 Si Pruebas Exitosas

¡El bug está arreglado! Todas las configuraciones ahora se sincronizan entre localStorage y Firebase.

Síntomas de éxito:
✅ Cambias configuración → se guarda
✅ Recarga → persiste
✅ Cieras sesión y abres → se mantiene


# Fullscreen CSS Fixes

This file contains the CSS changes needed to fix fullscreen experience.

## Changes Summary:

1. **player-overlay fullscreen styles**: Add proper positioning, z-index, overflow
2. **Hide headers/meta in fullscreen**: Set display: none for header, meta-panel
3. **Frame wrapper**: Remove padding, set flex properties
4. **Player container**: Add overflow: hidden, remove max-height constraints
5. **Cinema mode**: Use same structure as fullscreen
6. **Add landscape media queries**: For mobile orientation
7. **Add safe-area-inset**: For notch handling

## Implementation Details:

- Use position: fixed with top: 0; left: 0; right: 0; bottom: 0;
- Use max(100vw, 100vh) for truly full dimensions
- Remove all max-height constraints in fullscreen
- Set z-index: 2147483647 (max value)
- Add object-fit: contain on iframe
- Use overflow: hidden on all containers
- Add landscape media queries: @media (orientation: landscape) and max-height: 500px

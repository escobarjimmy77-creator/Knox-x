# 🚀 FASE 1 - GUÍA COMPLETA DE IMPLEMENTACIÓN

**Versión:** 2.0 (Nueva)  
**Fecha:** Mayo 5, 2026  
**Duración Estimada:** 1-2 horas  
**Riesgo:** ✅ BAJO - Solo reorganización de código  
**Complejidad:** ⭐ Fácil - Sin cambios lógicos  

---

## 📋 Resumen Ejecutivo

La **Fase 1** es un refactor de arquitectura que reorganiza el código existente sin modificar funcionalidad. El objetivo es crear una **base sólida, modular y escalable** para que las fases posteriores sean más limpias.

### Lo que lograras:
✅ Código organizado en carpetas temáticas  
✅ Eliminación de duplicación (Firebase config, constantes)  
✅ Servicios centralizados reutilizables  
✅ Base preparada para React/TypeScript  
✅ Funcionalidad 100% preservada  

### Tiempo aproximado:
- **Setup:** 15 min
- **Estructuras:** 20 min
- **Centralización:** 30 min
- **Pruebas:** 15 min
- **Total:** ~1.5 horas

---

## 🎯 OBJETIVOS DE FASE 1

| # | Objetivo | Estado | Prioridad |
|---|----------|--------|-----------|
| 1 | Crear estructura `/src` con subcarpetas | DEBE | 🔴 Alta |
| 2 | Centralizar Firebase config | DEBE | 🔴 Alta |
| 3 | Centralizar constantes de la app | DEBE | 🔴 Alta |
| 4 | Crear APIClient reutilizable | DEBE | 🔴 Alta |
| 5 | Crear RecommendationEngine | DEBE | 🔴 Alta |
| 6 | Centralizar helpers/utilidades | DEBE | 🔴 Alta |
| 7 | Eliminar duplicación | DEBE | 🔴 Alta |
| 8 | Documentar estructura | PUEDE | 🟡 Media |

---

## 📁 PASO 1: ESTRUCTURA DE CARPETAS

### Objetivo
Crear una estructura organizada que facilite el crecimiento del proyecto.

### Instrucciones

**Crea estas carpetas:**

```bash
cd src/

# Capa de datos
mkdir -p api/endpoints

# Servicios de negocio
mkdir -p services/firebase
mkdir -p services/recommendations
mkdir -p services/player

# Componentes y UI
mkdir -p components/AnimeCard
mkdir -p components/Player
mkdir -p components/Header

# Vistas/Páginas
mkdir -p views
mkdir -p views/Home
mkdir -p views/Player
mkdir -p views/Search

# React Hooks
mkdir -p hooks

# Estados/Store
mkdir -p state

# Utilidades
mkdir -p utils

# Tipos y constantes
mkdir -p types

# Estilos
mkdir -p styles

# PWA
mkdir -p pwa

# Listo: 14 carpetas creadas
```

### Resultado
```
src/
├── api/
│   ├── endpoints/
│   └── client.ts          ← Próximo paso
├── services/
│   ├── firebase/
│   ├── recommendations/
│   └── player/
├── components/           ← Para Fase 2
├── views/                ← Para Fase 2
├── hooks/                ← Para Fase 2
├── state/                ← Para Fase 2
├── utils/
├── types/
├── styles/
├── pwa/
└── README.md
```

---

## 🔐 PASO 2: CENTRALIZAR FIREBASE CONFIG

### Objetivo
Tener UN ÚNICO lugar donde vive la configuración de Firebase.

### Problema que resuelve
- ❌ Antes: Mismo config en `auth.js`, `user-sync.js`, `info-table.js` (3 copias)
- ✅ Después: Un único archivo que todos importan

### Instrucciones

**Crea:** `src/services/firebase/config.ts`

```typescript
/**
 * Firebase Configuration (Centralized)
 * Evita duplicación de credenciales entre múltiples archivos
 */

export const FB_CONFIG = {
    apiKey:            "AIzaSyCr1bcF_Lc1lKNoTmVYqIduwDqZIxK-mrM",
    authDomain:        "cerberusai-87db2.firebaseapp.com",
    projectId:         "cerberusai-87db2",
    storageBucket:     "cerberusai-87db2.firebasestorage.app",
    messagingSenderId: "942100846980",
    appId:             "1:942100846980:web:b1437acb40fc973a0d25d1",
    databaseURL:       "https://cerberusai-87db2-default-rtdb.firebaseio.com"
};

// Firebase app name to avoid conflicts with multiple instances
export const FB_APP_NAME = 'animesao-pro';
```

### Verificar
```bash
# ✅ Si no hay errores, está correcto
npx tsc --noEmit src/services/firebase/config.ts
```

---

## 🔗 PASO 3: CENTRALIZAR FIREBASE INIT

### Objetivo
Crear funciones reutilizables para inicializar y acceder a Firebase.

### Instrucciones

**Crea:** `src/services/firebase/index.ts`

```typescript
/**
 * Firebase Service - Inicialización centralizada
 */

import { FB_CONFIG, FB_APP_NAME } from './config';
import { initializeApp, getApps } from 'firebase/app';
import { getDatabase, Database } from 'firebase/database';
import { getAuth, Auth } from 'firebase/auth';

let fbApp: any = null;
let fbDatabase: Database | null = null;
let fbAuth: Auth | null = null;

/**
 * Inicializa Firebase (lazy)
 */
function initFirebase() {
    if (fbApp) return fbApp;
    
    const existingApps = getApps();
    const existing = existingApps.find(app => app.name === FB_APP_NAME);
    
    if (existing) {
        fbApp = existing;
    } else {
        fbApp = initializeApp(FB_CONFIG, FB_APP_NAME);
    }
    
    return fbApp;
}

/**
 * Obtener instancia de Firebase App
 */
export function getFirebaseApp() {
    if (!fbApp) initFirebase();
    return fbApp;
}

/**
 * Obtener instancia de Realtime Database
 */
export function getFirebaseDB(): Database {
    if (!fbDatabase) {
        const app = getFirebaseApp();
        fbDatabase = getDatabase(app);
    }
    return fbDatabase;
}

/**
 * Obtener instancia de Firebase Auth
 */
export function getFirebaseAuth(): Auth {
    if (!fbAuth) {
        const app = getFirebaseApp();
        fbAuth = getAuth(app);
    }
    return fbAuth;
}

export { FB_CONFIG, FB_APP_NAME } from './config';
```

---

## 📦 PASO 4: CENTRALIZAR CONSTANTES

### Objetivo
Un archivo único con TODAS las constantes de la app.

### Instrucciones

**Crea:** `src/types/constants.ts`

```typescript
/**
 * Constants - Configuración centralizada de la aplicación
 */

// API Configuration
export const API_BASE = "/api";

// Secciones del menú
export const SECTIONS_CONFIG = [
    { id: "latest", title: "Añadidos Recientemente", type: "latest", endpoint: "latest" },
    { id: "trending", title: "Animes Populares", type: "trending", endpoint: "trending" },
    { id: "action", title: "Acción", type: "genre", endpoint: "genre/accion" },
    { id: "comedy", title: "Comedia", type: "genre", endpoint: "genre/comedia" },
    { id: "romance", title: "Romance", type: "genre", endpoint: "genre/romance" },
    { id: "fantasy", title: "Fantasía", type: "genre", endpoint: "genre/fantasia" },
    { id: "isekai", title: "Isekai", type: "genre", endpoint: "genre/isekai" },
    { id: "drama", title: "Drama", type: "genre", endpoint: "genre/drama" },
    { id: "shounen", title: "Shounen", type: "genre", endpoint: "genre/shounen" },
    { id: "mystery", title: "Misterio", type: "genre", endpoint: "genre/misterio" },
];

// Recomendaciones configuración
export const RECOMMENDATION_CONFIG = {
    maxItems: 200,
    maxAge: 90 * 24 * 60 * 60 * 1000, // 90 días
    genreWeights: { action: 1.5, comedy: 1.2, shounen: 1.4, isekai: 1.3 },
    decayRate: 0.95,
    minScore: 20,
};

// Cache configuración
export const CACHE_CONFIG = {
    duration: 15 * 60 * 1000, // 15 minutos
    maxSize: 100,
    cleanup: 10 * 60 * 1000, // Limpiar cada 10 min
};

// UI Configuration
export const UI_CONFIG = {
    debounceDelay: 300,
    animationDuration: 300,
    toastTimeout: 3000,
    loadMoreThreshold: 500, // px antes del final
    itemsPerPage: 24,
};

// SVG Icons
export const ICONS = {
    CHEVRON: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"></polyline></svg>`,
    USER: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`,
};

// Auth Configuration
export const AUTH_SCREENS = {
    HOME: 'home',
    LOGIN: 'login',
    REGISTER: 'register',
    PROFILE: 'profile',
};

// Password validation
export const PASSWORD_RULES = {
    minLength: 8,
    requireUppercase: true,
    requireNumbers: true,
    requireSpecial: true,
};

// Username configuration
export const USERNAME_CONFIG = {
    minLength: 3,
    maxLength: 32,
    pattern: /^[a-zA-Z0-9_-]+$/,
    cooldown: 24 * 60 * 60 * 1000, // 24 horas cambio
};

// Base64 placeholder
export const BLANK_IMAGE_BASE64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
```

---

## 🔌 PASO 5: CREAR API CLIENT CENTRALIZADO

### Objetivo
Una clase reutilizable para TODOS los requests a la API.

### Instrucciones

**Crea:** `src/api/client.ts`

```typescript
/**
 * API Client - Gestión centralizada de requests
 */

import { API_BASE, CACHE_CONFIG } from '../types/constants';

export interface ApiResponse<T> {
    success: boolean;
    error?: string;
    data: T | null;
}

export interface AnimeInfo {
    id: string;
    title: string;
    cover: string;
    lastEpisode: string;
    genres: string[];
    [key: string]: any;
}

/**
 * APIClient - Clase para gestionar todas las llamadas a API
 */
export class APIClient {
    private requestCache: Map<string, any> = new Map();

    async fetch<T>(endpoint: string, params: Record<string, any> = {}): Promise<ApiResponse<T>> {
        try {
            const queryString = new URLSearchParams(params).toString();
            const url = `${API_BASE}/${endpoint}${queryString ? '?' + queryString : ''}`;

            // No cachear si se solicita explícitamente
            if (params.nocache) {
                const res = await fetch(url);
                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                const data = await res.json();
                return { success: true, data };
            }

            // Verificar cache
            if (this.requestCache.has(url)) {
                return { success: true, data: this.requestCache.get(url) };
            }

            // Fetch real
            const res = await fetch(url);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const data = await res.json();

            // Guardar en cache
            this.requestCache.set(url, data);
            setTimeout(() => this.requestCache.delete(url), CACHE_CONFIG.duration);

            return { success: true, data };
        } catch (error: any) {
            console.error(`[APIClient] Error en ${endpoint}:`, error);
            return { success: false, error: error.message, data: null };
        }
    }

    // Métodos específicos para cada endpoint
    async getLatest(page = 1, nocache = false): Promise<ApiResponse<AnimeInfo[]>> {
        return this.fetch('latest', { page, nocache });
    }

    async getTrending(nocache = false): Promise<ApiResponse<AnimeInfo[]>> {
        return this.fetch('trending', { nocache });
    }

    async getGenre(genre: string, page = 1, nocache = false): Promise<ApiResponse<AnimeInfo[]>> {
        return this.fetch(`genre/${genre}`, { page, nocache });
    }

    async search(query: string): Promise<ApiResponse<AnimeInfo[]>> {
        return this.fetch('search', { q: encodeURIComponent(query) });
    }

    async getInfo(id: string): Promise<ApiResponse<any>> {
        return this.fetch(`info/${id}`);
    }

    async getVideo(id: string, episode: number): Promise<ApiResponse<any>> {
        return this.fetch(`video/${id}/${episode}`);
    }

    clearCache(): void {
        this.requestCache.clear();
    }
}

// Instancia singleton
export const apiClient = new APIClient();
```

---

## 🤖 PASO 6: CREAR RECOMMENDATION ENGINE

### Objetivo
Un servicio para gestionar recomendaciones de anime.

### Instrucciones

**Crea:** `src/services/recommendations/engine.ts`

```typescript
/**
 * Recommendation Engine - Genera recomendaciones personalizadas
 */

import { RECOMMENDATION_CONFIG } from '../../types/constants';

export interface AnimeScore {
    id: string;
    title: string;
    score: number;
    reason?: string;
}

interface UserProfile {
    watchedIds: Set<string>;
    favoriteGenres: Map<string, number>;
    genreHistory: Array<{ genre: string; count: number; timestamp: number }>;
    watchHistory: Array<{ id: string; title: string; timestamp: number }>;
}

export class RecommendationEngine {
    private profile: UserProfile = {
        watchedIds: new Set(),
        favoriteGenres: new Map(),
        genreHistory: [],
        watchHistory: [],
    };

    track(action: 'watch' | 'favorite' | 'rate', anime: any, rating?: number) {
        const now = Date.now();

        if (action === 'watch' || action === 'favorite') {
            this.profile.watchedIds.add(anime.id);
            this.profile.watchHistory.push({
                id: anime.id,
                title: anime.title,
                timestamp: now,
            });

            // Limpiar historia muy vieja
            this.profile.watchHistory = this.profile.watchHistory.filter(
                w => now - w.timestamp < RECOMMENDATION_CONFIG.maxAge
            );
        }

        if (anime.genres) {
            anime.genres.forEach((genre: string) => {
                const current = this.profile.favoriteGenres.get(genre) || 0;
                this.profile.favoriteGenres.set(genre, current + 1);
            });
        }
    }

    scoreAnime(anime: any): number {
        let score = 0;

        // Penalizar si ya lo vio
        if (this.profile.watchedIds.has(anime.id)) return 0;

        // Bonus por géneros favoritos
        if (anime.genres) {
            anime.genres.forEach((genre: string) => {
                const genreScore = this.profile.favoriteGenres.get(genre) || 0;
                const config = RECOMMENDATION_CONFIG.genreWeights as Record<string, number>;
                score += (genreScore * (config[genre] || 1)) * 10;
            });
        }

        return Math.max(RECOMMENDATION_CONFIG.minScore, score);
    }

    getRanked(items: any[], limit = 15): AnimeScore[] {
        return items
            .map(item => ({ ...item, score: this.scoreAnime(item) }))
            .filter(item => item.score > 0)
            .sort((a, b) => b.score - a.score)
            .slice(0, limit);
    }

    getSimilar(targetAnime: any, items: any[], limit = 8): AnimeScore[] {
        if (!targetAnime.genres || !Array.isArray(targetAnime.genres)) {
            return [];
        }

        const targetGenres = new Set(targetAnime.genres);
        const scored = items
            .filter(item => item.id !== targetAnime.id && !this.profile.watchedIds.has(item.id))
            .map(item => {
                let score = 0;
                if (item.genres) {
                    item.genres.forEach((genre: string) => {
                        if (targetGenres.has(genre)) score += 20;
                    });
                }
                return { ...item, score };
            })
            .sort((a, b) => b.score - a.score)
            .slice(0, limit);

        return scored;
    }

    registerFavorite(anime: any, isFav: boolean) {
        this.track('favorite', anime);
    }

    registerEpisodeWatch(anime: any) {
        this.track('watch', anime);
    }

    getTopGenre(): string | null {
        if (this.profile.favoriteGenres.size === 0) return null;
        let top = null;
        let maxScore = 0;

        this.profile.favoriteGenres.forEach((score, genre) => {
            if (score > maxScore) {
                maxScore = score;
                top = genre;
            }
        });

        return top;
    }

    getPreferences(): Record<string, number> {
        const result: Record<string, number> = {};
        this.profile.favoriteGenres.forEach((score, genre) => {
            result[genre] = score;
        });
        return result;
    }

    getWatchHistory() {
        return this.profile.watchHistory;
    }

    clearHistory() {
        this.profile.watchHistory = [];
        this.profile.watchedIds.clear();
        this.profile.favoriteGenres.clear();
    }
}

// Instancia singleton
let instance: RecommendationEngine | null = null;

export function getRecommendationEngine(): RecommendationEngine {
    if (!instance) {
        instance = new RecommendationEngine();
    }
    return instance;
}
```

---

## 🛠️ PASO 7: CENTRALIZAR HELPERS/UTILIDADES

### Objetivo
Un archivo con funciones útiles reutilizables en toda la app.

### Instrucciones

**Crea:** `src/utils/helpers.ts`

```typescript
/**
 * Helper Functions - Utilidades centralizadas
 */

/**
 * $ - DOM selector shortcut
 */
export const $ = (selector: string): HTMLElement | null => {
    return document.querySelector(selector);
};

/**
 * Escapar HTML para evitar XSS
 */
export const esc = (s: string | null | undefined): string => {
    const str = String(s ?? '');
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
};

/**
 * Debounce function
 */
export const debounce = (
    fn: (...args: any[]) => void,
    delay: number
): ((...args: any[]) => void) => {
    let timeoutId: NodeJS.Timeout;
    return (...args: any[]) => {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => fn(...args), delay);
    };
};

/**
 * Delay (promesa)
 */
export const delay = (ms: number): Promise<void> => {
    return new Promise(resolve => setTimeout(resolve, ms));
};

/**
 * Shufflear array
 */
export const shuffleArray = <T>(arr: T[]): T[] => {
    const copy = [...arr];
    for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
};

/**
 * Toast notification
 */
export const showToast = (message: string, duration = 3000) => {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 20px;
        background: #333;
        color: white;
        padding: 12px 20px;
        border-radius: 6px;
        font-size: 14px;
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), duration);
};

/**
 * Normalizar username (lowercase, trim)
 */
export const normalizeUsername = (username: string): string => {
    return username.toLowerCase().trim();
};

/**
 * Parse JSON seguro
 */
export const safeJsonParse = (json: string, fallback: any = null) => {
    try {
        return JSON.parse(json);
    } catch {
        return fallback;
    }
};

/**
 * Firebase key sanitization
 */
export const fbKey = (id: string | number): string => {
    return String(id).replace(/[.#$\/\[\]]/g, '_');
};

/**
 * Merge arrays by timestamp
 */
export const mergeArraysByTimestamp = (a: any[], b: any[]): any[] => {
    const merged = [...a, ...b];
    merged.sort((x, y) => (y.timestamp || 0) - (x.timestamp || 0));
    
    const seen = new Set();
    return merged.filter(item => {
        if (seen.has(item.id)) return false;
        seen.add(item.id);
        return true;
    });
};

/**
 * Format timestamp como "May 5, 2026"
 */
export const formatTimestamp = (ts: number): string => {
    return new Date(ts).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
};

/**
 * Jaccard similarity (para comparar géneros)
 */
export const jaccardSimilarity = (a: string[], b: string[]): number => {
    const setA = new Set(a);
    const setB = new Set(b);
    const intersection = new Set([...setA].filter(x => setB.has(x)));
    const union = new Set([...setA, ...setB]);
    return intersection.size / union.size || 0;
};

/**
 * Caché de elementos DOM
 */
export class ElementCache {
    private cache = new Map<string, HTMLElement | null>();

    get(selector: string): HTMLElement | null {
        if (!this.cache.has(selector)) {
            this.cache.set(selector, document.querySelector(selector));
        }
        return this.cache.get(selector) || null;
    }

    clear() {
        this.cache.clear();
    }
}

// Instancia singleton
export const elemCache = new ElementCache();
```

---

## ✅ PASO 8: VERIFICAR DEPENDENCIAS

### Objetivo
Asegurarse que todo compile sin errores.

### Instrucciones

```bash
# Arreglar TypeScript
npm run lint

# Debería mostrar: "0 errors"

# Build result
npm run build

# Debería estar verde: "✓ built"
```

---

## 📊 RESULTADOS ESPERADOS

### ✅ Archivos Creados (7)
```
src/api/client.ts                  135 líneas
src/services/firebase/config.ts    9 líneas
src/services/firebase/index.ts     32 líneas
src/services/recommendations/engine.ts   195 líneas
src/types/constants.ts             76 líneas
src/utils/helpers.ts               155 líneas
src/README.md                      Documentación
────────────────────────────────────────────
Total:                             602 líneas
```

### ✅ Funcionalidad Preservada
```
✅ Firebase auth sigue funcionando
✅ API requests sigue funcionando  
✅ Recomendaciones funcionan
✅ Todos los scripts (auth, user-sync, info-table) siguen activos
```

### ✅ Ventajas Logradas
| Ventaja | Antes | Después | Beneficio |
|---------|-------|---------|-----------|
| Duplicación | 3x config | 1x config | -60 LOC |
| Responsabilidad | Difusa | Clara | +Mantenibilidad |
| Testing | Difícil | Fácil | +Testing |
| Reutilización | Baja | Alta | +Velocidad |
| Escalabilidad | Media | Alta | +Crecimiento |

---

## 🔄 INTEGRACIÓN CON OTRAS FASES (Bajo riesgo)

### ✅ Agregar sin riesgo en Fase 1:

#### 1. **Zustand Store básico** (Bajo riesgo)
Agregar una carpeta `src/state/store.ts` con store global. No interfiere con código existente.

```typescript
// src/state/store.ts
import { create } from 'zustand';

interface Store {
    currentUser: any | null;
    setCurrentUser: (user: any) => void;
}

export const useStore = create<Store>((set) => ({
    currentUser: null,
    setCurrentUser: (user) => set({ currentUser: user }),
}));
```

**Riesgo:** Bajo - No toca código existente
**Beneficio:** Setup para Fase 2

---

#### 2. **Tipos TypeScript para Anime** (Bajo riesgo)
Agregar `src/types/anime.ts` con interfaces.

```typescript
// src/types/anime.ts
export interface Anime {
    id: string;
    title: string;
    cover: string;
    genres: string[];
    status: string;
    episodes?: number;
}

export interface Episode {
    number: number;
    id: string;
    title?: string;
}
```

**Riesgo:** Bajo - Solo tipos
**Beneficio:** Type safety inmediato

---

#### 3. **Logger centralizado** (Bajo riesgo)
Agregar `src/utils/logger.ts` para debug.

```typescript
// src/utils/logger.ts
export const logger = {
    log: (tag: string, msg: string, data?: any) => {
        console.log(`[${tag}]`, msg, data);
    },
    error: (tag: string, msg: string, error?: any) => {
        console.error(`[${tag}]`, msg, error);
    },
};
```

**Riesgo:** Bajo - Opcional
**Beneficio:** Debugging más limpio

---

## 🚨 NO HACER EN FASE 1

❌ NO cambiar lógica de Firebase auth  
❌ NO modificar script.js masivamente  
❌ NO agregar React components  
❌ NO cambiar CSS  
❌ NO cambiar endpoints del backend  
❌ NO refactorizar video player  

**Razón:** Podrías romper cosas que funcionan.

---

## 📝 CHECKLIST FINAL

- [ ] Crear carpetas de `src/`
- [ ] Crear `src/services/firebase/config.ts`
- [ ] Crear `src/services/firebase/index.ts`
- [ ] Crear `src/types/constants.ts`
- [ ] Crear `src/api/client.ts`
- [ ] Crear `src/services/recommendations/engine.ts`
- [ ] Crear `src/utils/helpers.ts`
- [ ] Ejecutar `npm run lint` ✅
- [ ] Ejecutar `npm run build` ✅
- [ ] Probar que todo sigue funcionando
- [ ] Documentar cambios en commit
- [ ] ✨ FASE 1 COMPLETADA ✨

---

## 🎯 PRÓXIMOS PASOS (Fase 2 y 3)

### Fase 2: **Refactor de script.js a módulos**
- Convertir script.js a múltiples módulos TypeScript
- Usar importa de APIClient, constants, helpers
- Eliminar duplicación

### Fase 3: **React components**
- `<AnimeCard />` - Tarjeta de anime
- `<Player />` - Video player
- `<Search />` - Búsqueda
- Home, Profile, etc.

### Fase 4: **Migración a Vite + React**
- Reemplazar vanilla JS completamente
- Usar Zustand para estado global
- Tailwind CSS

---

## 📞 SOPORTE

Si algo no funciona:
1. Verifica que todas las carpetas existan
2. Comprueba que los imports son correctos
3. Ejecuta `npm run lint` para errores
4. Revisa la consola del navegador

---

**✅ FASE 1 LISTA PARA IMPLEMENTAR** ✅

Tiempo estimado: **1-2 horas**  
Complejidad: **⭐ Fácil**  
Riesgo: **BAJO**

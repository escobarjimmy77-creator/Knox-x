/**
 * API Client - Gestión centralizada de requests
 */

import { API_BASE, CACHE_CONFIG } from '../types/constants';

export interface ApiResponse<T> {
    success: boolean;
    error?: string;
    data: T | null;
}

export interface AnimeInfo {
    id: string;
    title: string;
    cover: string;
    lastEpisode: string;
    genres: string[];
    [key: string]: any;
}

export class APIClient {
    private requestCache: Map<string, any> = new Map();

    private getCacheKey(endpoint: string, params: Record<string, any>) {
        const query = Object.keys(params)
            .sort()
            .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(String(params[key] ?? ''))}`)
            .join('&');
        return `${endpoint}?${query}`;
    }

    private async request<T>(endpoint: string, params: Record<string, any> = {}): Promise<ApiResponse<T>> {
        const cacheKey = this.getCacheKey(endpoint, params);
        const useCache = !params.nocache;

        if (useCache && this.requestCache.has(cacheKey)) {
            return { success: true, data: this.requestCache.get(cacheKey), error: undefined };
        }

        try {
            const query = new URLSearchParams(params as Record<string, string>);
            const url = `${API_BASE}/${endpoint}${query.toString() ? `?${query.toString()}` : ''}`;
            const response = await fetch(url, { cache: 'no-store' });
            const json = await response.json();

            if (!response.ok) {
                return { success: false, data: null, error: json?.error || 'Error en la petición.' };
            }

            if (useCache) {
                this.requestCache.set(cacheKey, json.data ?? json);
                if (this.requestCache.size > CACHE_CONFIG.maxSize) {
                    const firstKey = this.requestCache.keys().next().value;
                    this.requestCache.delete(firstKey);
                }
            }

            return { success: true, data: json.data ?? json };
        } catch (error) {
            return {
                success: false,
                data: null,
                error: error instanceof Error ? error.message : 'Error desconocido en la red.',
            };
        }
    }

    async fetch<T>(endpoint: string, params: Record<string, any> = {}): Promise<ApiResponse<T>> {
        return this.request<T>(endpoint, params);
    }

    async getLatest(page = 1, nocache = false): Promise<ApiResponse<AnimeInfo[]>> {
        return this.fetch<AnimeInfo[]>('latest', { page, nocache });
    }

    async getTrending(page = 1, nocache = false): Promise<ApiResponse<AnimeInfo[]>> {
        return this.fetch<AnimeInfo[]>('trending', { page, nocache });
    }

    async search(query: string, page = 1, nocache = false): Promise<ApiResponse<AnimeInfo[]>> {
        return this.fetch<AnimeInfo[]>('search', { q: query, page, nocache });
    }

    async getAnimeById(id: string): Promise<ApiResponse<AnimeInfo>> {
        return this.fetch<AnimeInfo>(`anime/${encodeURIComponent(id)}`);
    }
}

export const apiClient = new APIClient();

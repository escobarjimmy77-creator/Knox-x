# src

## Estructura de la carpeta `src`

Este directorio contiene la base modular para la aplicación.

### api/
- `client.ts`: Cliente centralizado para llamadas a la API.

### services/
- `firebase/`: Inicialización y configuración de Firebase.
- `recommendations/`: Motor de recomendaciones personalizado.

### types/
- `constants.ts`: Constantes reutilizables de la aplicación.

### utils/
- `helpers.ts`: Funciones utilitarias para DOM, parseo, debouncing y más.

## Uso

Esta fase mantiene la funcionalidad actual, pero centraliza la configuración y los servicios.

- `src/services/firebase/config.ts`: única fuente de truth para la configuración de Firebase.
- `src/services/firebase/index.ts`: inicializa Firebase y expone getters para `app`, `database` y `auth`.
- `src/types/constants.ts`: constantes compartidas para endpoints, UI y recomendaciones.
- `src/api/client.ts`: cliente API reutilizable.
- `src/services/recommendations/engine.ts`: motor básico de puntuación de recomendaciones.
- `src/utils/helpers.ts`: helpers comunes que se pueden usar en la app.

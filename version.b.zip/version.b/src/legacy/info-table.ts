// info-table.js — AnimeSAO Pro Info Panel v4
// Slide-up bottom sheet overlay. Does NOT use window.Navigation.
// @ts-nocheck
import { getFirebaseApp, getFirebaseDB } from '../services/firebase/index.ts';
import { ref, onValue, push, get } from 'firebase/database';

const $    = id  => document.getElementById(id);
const esc  = s   => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '<').replace(/>/g, '>');
const toast = msg => { try { window.showToast?.(msg); } catch (_) {} };
const fmt  = ts  => {
    if (!ts) return '—';
    const diff = Date.now() - ts;
    if (diff < 60000)    return 'Ahora';
    if (diff < 3600000)  return `${Math.floor(diff / 60000)}m`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h`;
    return new Date(ts).toLocaleDateString('es', { day: 'numeric', month: 'short' });
};

let _db = null;
try {
    const app = getFirebaseApp();
    _db = getFirebaseDB();
} catch (e) { console.warn('[InfoPanel] Firebase:', e.message); }

let _activeTab  = 'status';
let _loadedTabs = new Set();
let _comFilter  = 'all';
let _comTipo    = 'pregunta';
let _allPosts   = [];
let _unsubs     = [];

// ── Open / Close ─────────────────────────────────────────────────────────────
function open() {
    const overlay = $('info-panel');
    if (!overlay) { console.warn('[InfoPanel] #info-panel not found in DOM'); return; }
    overlay.classList.add('ip-open');
    overlay.removeAttribute('aria-hidden');
    document.body.style.overflow = 'hidden';
    _loadStats();
    // Small delay so CSS transition fires after display change
    requestAnimationFrame(() => _switchTab(_activeTab));
}

function close() {
    const overlay = $('info-panel');
    if (!overlay) return;
    overlay.classList.remove('ip-open');
    overlay.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
}

// ── Stats bar ─────────────────────────────────────────────────────────────────
function _loadStats() {
    try {
        const lib  = JSON.parse(localStorage.getItem('anime_library')  || '[]');
        const hist = JSON.parse(localStorage.getItem('anime_history') || '[]');
        const set2 = (id, v) => { const el = $(id); if (el) el.textContent = v; };
        set2('ip-stat-lib',       lib.length);
        set2('ip-stat-watched',   new Set(hist.map(h => h.id)).size);
        set2('ip-stat-completed', lib.filter(i => i.status === 'completed').length);
        set2('ip-stat-favs',      lib.filter(i => i.favorite).length);
    } catch (_) {}
}

// ── Tab switching ─────────────────────────────────────────────────────────────
function _switchTab(tab) {
    _activeTab = tab;

    document.querySelectorAll('.ip-tab-btn').forEach(btn =>
        btn.classList.toggle('active', btn.dataset.tab === tab));

    _updateInk(tab);

    document.querySelectorAll('.ip-panel').forEach(p =>
        p.classList.toggle('active', p.dataset.tab === tab));

    if (!_loadedTabs.has(tab)) {
        _loadedTabs.add(tab);
        if (tab === 'status')    _loadStatus();
        if (tab === 'community') _loadCommunity();
        if (tab === 'errors')    _loadErrors();
        if (tab === 'notes')     _loadNotes();
    }
}

function _updateInk(tab) {
    const btn = document.querySelector(`.ip-tab-btn[data-tab="${tab}"]`);
    const ink = $('ip-tab-ink');
    if (btn && ink) {
        ink.style.left  = btn.offsetLeft + 'px';
        ink.style.width = btn.offsetWidth + 'px';
    }
}

// ── Status tab ────────────────────────────────────────────────────────────────
async function _loadStatus() {
    const statusDot  = $('ip-status-dot');
    const statusRing = $('ip-status-ring');
    const statusTitleEl = $('ip-status-title');
    const statusSubEl   = $('ip-status-sub');
    const ipSubtitle    = $('ip-subtitle');

    // Server check
    let serverOk = false;
    try {
        const r = await fetch('/api/health', { signal: AbortSignal.timeout(5000) });
        serverOk = r.ok;
    } catch (_) {}
    _setComp('server', serverOk ? 'ok' : 'error',
        serverOk ? 'Operativo'   : 'Sin respuesta',
        serverOk ? 'Respondiendo correctamente' : 'No se pudo conectar',
        serverOk ? 'Online'      : 'Offline');

    // Gemini check
    const gemOk = !!localStorage.getItem('gemini_api_key');
    _setComp('gemini', gemOk ? 'ok' : 'warn',
        gemOk ? 'Activa'         : 'Sin configurar',
        gemOk ? 'API key detectada' : 'Configura una clave en ajustes',
        gemOk ? 'OK'             : 'Sin clave');

    // Firebase check
    let fbOk = false;
    try { if (_db) { await get(ref(_db, '.info/connected')); fbOk = true; } } catch (_) {}
    _setComp('firebase', fbOk ? 'ok' : 'error',
        fbOk ? 'Conectado'       : 'Sin conexión',
        fbOk ? 'Tiempo real activo' : 'No se pudo alcanzar Firebase',
        fbOk ? 'Online'          : 'Offline');

    // Overall
    const status = (!serverOk || !fbOk) ? 'error' : !gemOk ? 'warn' : 'ok';
    const dotCls = { ok: 'ip-app-dot', warn: 'ip-app-dot warn', error: 'ip-app-dot error' }[status];
    const rngCls = { ok: 'ip-status-ring', warn: 'ip-status-ring warn', error: 'ip-status-ring error' }[status];

    const ICONS = {
        ok:    `<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>`,
        warn:  `<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
        error: `<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`
    };
    const TITLES = { ok: 'Todo operativo', warn: 'Advertencia activa', error: 'Problema detectado' };
    const SUBS   = {
        ok:    'Todos los servicios funcionan correctamente',
        warn:  'Gemini AI sin clave configurada',
        error: 'Se detectó un fallo en un servicio'
    };

    if (statusDot)      statusDot.className      = dotCls;
    if (statusRing)   { statusRing.className      = rngCls; statusRing.innerHTML = ICONS[status]; }
    if (statusTitleEl)  statusTitleEl.textContent = TITLES[status];
    if (statusSubEl)    statusSubEl.textContent   = SUBS[status];
    if (ipSubtitle)     ipSubtitle.textContent    = TITLES[status];
}

function _setComp(name, state, label, desc, badge) {
    const dot = $(`ip-dot-${name}`);
    const lbl = $(`ip-label-${name}`);
    const sub = $(`ip-sub-${name}`);
    const bdg = $(`ip-badge-${name}`);
    const dotCls  = { ok: 'ip-comp-dot', warn: 'ip-comp-dot ip-dot--warn', error: 'ip-comp-dot ip-dot--error' };
    const badgeCls = { ok: 'ip-comp-badge', warn: 'ip-comp-badge ip-badge--warn', error: 'ip-comp-badge ip-badge--error' };
    if (dot) dot.className  = dotCls[state]   || 'ip-comp-dot';
    if (lbl) lbl.textContent = label;
    if (sub) sub.textContent = desc;
    if (bdg) { bdg.className = badgeCls[state] || 'ip-comp-badge'; bdg.textContent = badge; }
}

// ── Community tab ─────────────────────────────────────────────────────────────
function _loadCommunity() {
    if (!_db) return;
    const unsub = onValue(ref(_db, 'public/comunidad'), snap => {
        _allPosts = [];
        snap.forEach(child => _allPosts.unshift({ id: child.key, ...child.val() }));
        _renderCommunity();
    });
    _unsubs.push(unsub);
}

function _renderCommunity() {
    const feed   = $('ip-community-feed');
    const loader = $('ip-com-loader');
    if (!feed) return;
    if (loader) loader.remove();

    const TIPO_CLASS = { pregunta: '', idea: 'tipo-idea', error: 'tipo-error', general: 'tipo-general' };
    const TIPO_LABEL = { pregunta: 'Pregunta', idea: 'Idea', error: 'Error', general: 'General' };

    const filtered = _comFilter === 'all'
        ? _allPosts
        : _allPosts.filter(p => p.tipo === _comFilter);

    if (!filtered.length) {
        feed.innerHTML = `<div class="ip-empty">Sin publicaciones aún</div>`;
        return;
    }

    feed.innerHTML = filtered.map(p => {
        const init      = esc((p.username || 'U').charAt(0).toUpperCase());
        const tipoCls   = TIPO_CLASS[p.tipo] || '';
        const tipoLabel = TIPO_LABEL[p.tipo] || (p.tipo || 'General');
        return `<div class="ip-post-card">
            <div class="ip-post-header">
                <div class="ip-post-avatar">${init}</div>
                <div class="ip-post-meta">
                    <p class="ip-post-name">${esc(p.username || 'Anónimo')}</p>
                    <p class="ip-post-time">${fmt(p.ts)}</p>
                </div>
                <span class="ip-post-tipo ${tipoCls}">${tipoLabel}</span>
            </div>
            <p class="ip-post-body">${esc(p.text || '')}</p>
        </div>`;
    }).join('');
}

async function _submitPost() {
    const input  = $('ip-composer-input');
    const btn    = $('ip-submit-btn');
    const text   = (input?.value || '').trim();
    if (!text || !_db) { toast('Escribe algo primero'); return; }
    const username = localStorage.getItem('profile_username') || 'Anónimo';
    if (btn) btn.disabled = true;
    try {
        await push(ref(_db, 'public/comunidad'), { text, tipo: _comTipo, username, ts: Date.now() });
        input.value = '';
        const cc = $('ip-char-count'); if (cc) cc.textContent = '0/300';
        toast('¡Publicado!');
    } catch (_) { toast('Error al publicar'); }
    if (btn) btn.disabled = false;
}

// ── Errors tab ────────────────────────────────────────────────────────────────
function _loadErrors() {
    if (!_db) return;
    const unsub = onValue(ref(_db, 'public/errores'), snap => {
        const items = [];
        snap.forEach(child => items.unshift({ id: child.key, ...child.val() }));
        _renderErrors(items);
    });
    _unsubs.push(unsub);
}

function _renderErrors(items) {
    const list   = $('ip-errors-list');
    const loader = $('ip-err-loader');
    const banner = $('ip-err-banner');
    const title  = $('ip-err-title');
    const sub    = $('ip-err-sub');
    const icon   = $('ip-err-icon');
    if (!list) return;
    if (loader) loader.remove();

    const active = items.filter(e => !e.resolved);
    const isWarn = active.length > 0;

    if (banner) banner.className = 'ip-err-banner' + (isWarn ? ' ip-err-banner--warn' : '');
    if (title)  title.textContent = isWarn ? `${active.length} error${active.length !== 1 ? 'es' : ''} activo${active.length !== 1 ? 's' : ''}` : '¡Todo en orden!';
    if (sub)    sub.textContent   = isWarn ? 'Nuestro equipo está trabajando en ello' : 'Sin incidencias activas';
    if (icon)   icon.innerHTML    = isWarn
        ? `<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="#f97316" stroke-width="2.5" stroke-linecap="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`
        : `<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="#22c55e" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>`;

    if (!items.length) { list.innerHTML = '<div class="ip-empty">Sin errores registrados</div>'; return; }

    list.innerHTML = items.map(e => {
        const resolved = !!e.resolved;
        const cls      = 'ip-error-card' + (resolved ? ' ip-error-card--resolved' : '');
        const badge    = resolved
            ? `<span class="ip-error-badge-resolved">Resuelto</span>`
            : `<span class="ip-error-badge-active">Activo</span>`;
        return `<div class="${cls}">
            <p class="ip-error-title">${esc(e.title || 'Error')}</p>
            <p class="ip-error-desc">${esc(e.desc || '')}</p>
            <div class="ip-error-footer">${badge}<span class="ip-error-date">${fmt(e.ts)}</span></div>
        </div>`;
    }).join('');
}

// ── Notes tab ─────────────────────────────────────────────────────────────────
function _loadNotes() {
    if (!_db) return;

    get(ref(_db, 'public/footer')).then(snap => {
        const d = snap.val() || {};
        const nameEl   = $('ip-dev-name');
        const handleEl = $('ip-dev-handle');
        const ghBtn    = $('ip-social-github');
        const avatarEl = $('ip-dev-avatar');
        if (nameEl)   nameEl.textContent  = d.name   || 'Desarrollador';
        if (handleEl) handleEl.textContent = d.handle || '@animesaopro';
        if (ghBtn && d.github) ghBtn.href = d.github;
        if (avatarEl && d.avatar) {
            avatarEl.innerHTML = `<img src="${esc(d.avatar)}" alt="Dev"
                style="width:100%;height:100%;object-fit:cover;border-radius:50%;"
                onerror="this.style.display='none'">`;
        }
    }).catch(() => {});

    const unsub = onValue(ref(_db, 'public/notas'), snap => {
        const notes = [];
        snap.forEach(child => notes.unshift({ id: child.key, ...child.val() }));
        _renderNotes(notes);
    });
    _unsubs.push(unsub);
}

function _renderNotes(notes) {
    const list   = $('ip-notes-list');
    const loader = $('ip-notes-loader');
    if (!list) return;
    if (loader) loader.remove();

    if (!notes.length) { list.innerHTML = '<div class="ip-empty">Sin notas aún</div>'; return; }

    list.innerHTML = notes.map((n, i) => `
        <div class="ip-note-card">
            <div class="ip-note-dot-wrap">
                <div class="ip-note-dot"></div>
                ${i < notes.length - 1 ? '<div class="ip-note-line"></div>' : ''}
            </div>
            <div class="ip-note-body">
                <p class="ip-note-title">${esc(n.title || 'Nota')}</p>
                <p class="ip-note-text">${esc(n.text || '')}</p>
                <p class="ip-note-time">${fmt(n.ts)}</p>
            </div>
        </div>`).join('');
}

// ── Setup ─────────────────────────────────────────────────────────────────────
function _setup() {
    // Close button + backdrop
    $('ip-close')?.addEventListener('click', close);
    $('ip-backdrop')?.addEventListener('click', close);

    // Tab buttons
    document.querySelectorAll('.ip-tab-btn').forEach(btn =>
        btn.addEventListener('click', () => _switchTab(btn.dataset.tab)));

    // Tipo pills
    document.querySelectorAll('.ip-tipo-pill').forEach(p =>
        p.addEventListener('click', () => {
            _comTipo = p.dataset.tipo;
            document.querySelectorAll('.ip-tipo-pill').forEach(x => x.classList.remove('active'));
            p.classList.add('active');
        }));

    // Filter pills
    document.querySelectorAll('.ip-filter-pill').forEach(p =>
        p.addEventListener('click', () => {
            _comFilter = p.dataset.filter;
            document.querySelectorAll('.ip-filter-pill').forEach(x => x.classList.remove('active'));
            p.classList.add('active');
            _renderCommunity();
        }));

    // Composer
    const input  = $('ip-composer-input');
    const cc     = $('ip-char-count');
    const submit = $('ip-submit-btn');
    if (input && cc) input.addEventListener('input', () => { cc.textContent = `${input.value.length}/300`; });
    if (submit) submit.addEventListener('click', _submitPost);

    // Initial ink position (after layout)
    setTimeout(() => _updateInk('status'), 80);
}

document.addEventListener('DOMContentLoaded', _setup);

// ── Public API ────────────────────────────────────────────────────────────────
window.InfoPanel       = { open, close };
window.InfoTableManager = { open, close }; // backward compat
console.log('[InfoPanel] v4 ready ✓');

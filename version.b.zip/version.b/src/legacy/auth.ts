// auth.js — Firebase Authentication + Cloud Profile Sync
// @ts-nocheck
import { getFirebaseApp, getFirebaseDB, getFirebaseAuth } from '../services/firebase/index.ts';
import { ref, set, get, remove } from 'firebase/database';
import {
    getAuth, onAuthStateChanged,
    signInWithEmailAndPassword, createUserWithEmailAndPassword,
    signOut as fbSignOut,
    GoogleAuthProvider, GithubAuthProvider, signInWithPopup,
    sendEmailVerification, sendPasswordResetEmail, updateProfile
} from 'firebase/auth';

// ── Firebase init (reuse existing app if present) ────────────────────
let _app, _db, _auth;
try {
    _app  = getFirebaseApp();
    _db   = getFirebaseDB();
    _auth = getFirebaseAuth();
} catch(e) { console.warn('[Auth] Firebase init:', e.message); }

const $el     = id  => document.getElementById(id);
const toast   = msg => window.showToast?.(msg);
const esc     = s   => String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

let _currentUser  = null;
let _cloudProfile = null;

// ── RTDB: user data ──────────────────────────────────────────────────
async function saveUserProfile(user, extra = {}) {
    if (!_db || !user) return;
    const profileData = {
        displayName: user.displayName || extra.username || '',
        username:    extra.username   || user.displayName || '',
        photoURL:    user.photoURL    || '',
        email:       user.email       || '',
        updatedAt:   Date.now()
    };

    const profileExtendedData = {
        username:       profileData.username,
        bio:            extra.bio || '',
        favoriteGenres: extra.favoriteGenres || [],
        photoURL:       profileData.photoURL,
        updatedAt:      Date.now()
    };

    try {
        await Promise.all([
            set(ref(_db, `users/${user.uid}/profile`), profileData),
            set(ref(_db, `users/${user.uid}/profileExtended`), profileExtendedData)
        ]);
    } catch (error) {
        console.warn('[Auth] saveUserProfile:', error?.message || error);
    }
}

async function loadUserProfile(user) {
    if (!_db || !user) return null;
    try {
        const snapExtended = await get(ref(_db, `users/${user.uid}/profileExtended`));
        const extended = snapExtended.val();
        if (extended) return extended;
        const snap = await get(ref(_db, `users/${user.uid}/profile`));
        return snap.val() || null;
    } catch (error) {
        console.warn('[Auth] loadUserProfile:', error?.message || error);
        return null;
    }
}

async function savePreferences(uid) {
    if (!_db || !uid) return;
    const prefs = {
        aiPersonalization: localStorage.getItem('ai_personalization') !== 'off',
        aiCatalogOnly:     localStorage.getItem('ai_catalog_only')     === 'on',
        theme:             localStorage.getItem('theme')              || 'dark',
        accentColor:       localStorage.getItem('accent_color')       || '#6366f1',
        cardSize:          localStorage.getItem('card_size')          || 'normal',
        updatedAt:         Date.now()
    };
    try { await set(ref(_db, `users/${uid}/preferences`), prefs); } catch(error) { console.warn('[Auth] savePreferences:', error?.message || error); }
}

async function loadPreferences(uid) {
    if (!_db || !uid) return null;
    try {
        const snap = await get(ref(_db, `users/${uid}/preferences`));
        return snap.val() || null;
    } catch(error) { console.warn('[Auth] loadPreferences:', error?.message || error); return null; }
}

// ── Sync preferences: save to localStorage AND Firebase (if authenticated) ────
async function updatePreferencesLocal(key, value) {
    // Always save to localStorage
    localStorage.setItem(key, value);
    
    // Also sync to Firebase if user is authenticated
    if (_currentUser && _db) {
        try {
            await savePreferences(_currentUser.uid);
            console.log(`[Auth] Preferences synced to Firebase: ${key} = ${value}`);
        } catch (error) {
            console.warn('[Auth] updatePreferencesLocal sync failed:', error?.message);
            // Still continue — local storage is saved, Firebase will catch up eventually
        }
    }
}

// Expose for script.js to call when preferences change
window.updatePreferencesLocal = updatePreferencesLocal;

// ── Username system (simple, no uniqueness check) ──────────────────────

function applyPreferences(prefs) {
    if (!prefs) return;
    if (prefs.theme === 'light') {
        document.documentElement.setAttribute('data-theme', 'light');
        localStorage.setItem('theme', 'light');
    }
    if (prefs.accentColor) {
        document.documentElement.style.setProperty('--accent-primary', prefs.accentColor);
        localStorage.setItem('accent_color', prefs.accentColor);
    }
    if (prefs.cardSize) localStorage.setItem('card_size', prefs.cardSize);
}

// ── Settings profile card ────────────────────────────────────────────
function updateSettingsCard(user, profile) {
    const avatarEl  = $el('cfg-avatar');
    const nameEl    = document.querySelector('.cfg-profile-name');
    const subEl     = document.querySelector('.cfg-profile-sub');
    const syncEl    = $el('cfg-profile-sync');
    const btnEl     = $el('cfg-edit-profile');
    const genreWrap = $el('cfg-profile-genres');

    if (!user) {
        if (avatarEl)   avatarEl.innerHTML = ICON_USER;
        if (nameEl)     nameEl.innerHTML   = 'Cuenta';
        if (subEl)    { subEl.textContent  = 'Inicia sesión para guardar tus datos en la nube'; subEl.style.display = ''; }
        if (syncEl)     syncEl.style.display = 'none';
        if (btnEl)      btnEl.innerHTML    = `Acceder ${ICON_CHEVRON}`;
        if (genreWrap)  genreWrap.style.display = '';
        return;
    }

    // Never use email as display name — fall back to 'Usuario'
    const cloudUsername = profile?.username || '';
    const localUsername = localStorage.getItem('profile_username') || '';
    const name     = cloudUsername || localUsername || profile?.displayName || user.displayName || 'Usuario';
    const cloudPhoto = profile?.photoURL || '';
    const localPhoto = localStorage.getItem('profile_photo') || '';
    const photoURL = cloudPhoto || localPhoto || user.photoURL || '';

    if (avatarEl) {
        if (photoURL) {
            avatarEl.innerHTML = `<img src="${esc(photoURL)}" alt="Avatar" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" onerror="this.parentElement.innerHTML='<span class=cfg-avatar-initials>${esc(name.charAt(0).toUpperCase())}</span>'">`;
        } else {
            avatarEl.innerHTML = `<span class="cfg-avatar-initials">${esc(name.charAt(0).toUpperCase())}</span>`;
        }
    }
    if (nameEl)    nameEl.innerHTML  = `${esc(name)} <svg class="cfg-verified" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#a78bfa" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>`;
    if (subEl)     subEl.style.display = 'none';
    if (syncEl)  { syncEl.style.display = ''; syncEl.textContent = '☁️ Cuenta sincronizada'; }
    if (btnEl)     btnEl.innerHTML  = `Editar ${ICON_CHEVRON}`;
    if (genreWrap) {
        if (profile?.favoriteGenres?.length) {
            const labels = { accion:"Acción", comedia:"Comedia", romance:"Romance", isekai:"Isekai",
                shounen:"Shōnen", aventura:"Aventura", fantasia:"Fantasía", drama:"Drama",
                terror:"Terror", misterio:"Misterio" };
            genreWrap.innerHTML = profile.favoriteGenres.map(g => `<span class="cfg-genre-badge">${labels[g] || g}</span>`).join("");
            genreWrap.classList.add("has-genres");
        } else {
            genreWrap.innerHTML = "";
            genreWrap.classList.remove("has-genres");
        }
    }

    // ── Auth account screen fields (show @username, never email) ──────
    const accountNameEl   = $el('auth-account-name');
    const accountEmailEl  = $el('auth-account-email');
    const accountAvatarEl = $el('auth-account-avatar');
    if (accountNameEl)  accountNameEl.textContent  = name;
    if (accountEmailEl) accountEmailEl.textContent = name ? `@${_normalizeUsername(name)}` : 'Cuenta verificada';
    if (accountAvatarEl) {
        if (photoURL) {
            accountAvatarEl.innerHTML = `<img src="${esc(photoURL)}" alt="Avatar" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" onerror="this.style.display='none'">`;
        } else {
            accountAvatarEl.innerHTML = `<span style="font-size:26px;font-weight:700;color:#a78bfa;">${esc(name.charAt(0).toUpperCase())}</span>`;
        }
    }
}

const ICON_CHEVRON = `<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.8"><polyline points="9 18 15 12 9 6"/></svg>`;
const ICON_USER    = `<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>`;

// ── Auth overlay: screen management ─────────────────────────────────
const SCREENS = ['welcome','login','register','verify','account'];
let _currentScreen = 'welcome';
let _prevScreen    = 'welcome';

function show() {
    const overlay = $el('auth-overlay');
    if (!overlay) return;
    overlay.classList.add('auth-overlay--active');
    document.body.style.overflow = 'hidden';
}

function hide() {
    const overlay = $el('auth-overlay');
    if (!overlay) return;
    overlay.classList.remove('auth-overlay--active');
    document.body.style.overflow = '';
}

function showScreen(name, direction = 'forward') {
    SCREENS.forEach(s => {
        const el = $el(`auth-sc-${s}`);
        if (!el) return;
        el.classList.remove('auth-screen--active','auth-screen--slide-out-left','auth-screen--slide-out-right','auth-screen--slide-in-left','auth-screen--slide-in-right');
        if (s === name) {
            el.classList.add('auth-screen--active', direction === 'back' ? 'auth-screen--slide-in-right' : 'auth-screen--slide-in-left');
        } else if (s === _currentScreen) {
            el.classList.add(direction === 'back' ? 'auth-screen--slide-out-right' : 'auth-screen--slide-out-left');
        }
    });
    _prevScreen    = _currentScreen;
    _currentScreen = name;
}

function clearErrors() {
    [$el('auth-login-error'), $el('auth-reg-error')].forEach(el => { if (el) el.textContent = ''; });
}

function setLoading(btnId, loading, label) {
    const btn = $el(btnId);
    if (!btn) return;
    btn.disabled = loading;
    const target = btn.querySelector('span') || btn;
    if (!loading) target.textContent = label;
    else { btn.dataset.origLabel = target.textContent; target.textContent = 'Un momento...'; }
}

// ── Email / Password ─────────────────────────────────────────────────
async function loginWithEmail() {
    const email = $el('auth-login-email')?.value.trim();
    const pw    = $el('auth-login-pw')?.value;
    const errEl = $el('auth-login-error');
    if (!email || !pw) { if (errEl) errEl.textContent = 'Completa todos los campos.'; return; }
    if (!_auth) { if (errEl) errEl.textContent = 'Sin conexión con Firebase.'; return; }

    setLoading('auth-login-submit', true);
    try {
        await signInWithEmailAndPassword(_auth, email, pw);
        hide();
        clearErrors();
    } catch(e) {
        if (errEl) errEl.textContent = authErrorMsg(e.code);
    }
    setLoading('auth-login-submit', false, 'Iniciar sesión');
}

async function registerWithEmail() {
    const username = $el('auth-reg-username')?.value.trim();
    const email    = $el('auth-reg-email')?.value.trim();
    const pw       = $el('auth-reg-pw')?.value;
    const errEl    = $el('auth-reg-error');
    if (!username || !email || !pw) { if (errEl) errEl.textContent = 'Completa todos los campos.'; return; }
    if (pw.length < 8 || !/[a-zA-Z]/.test(pw) || !/[0-9]/.test(pw)) {
        if (errEl) errEl.textContent = 'La contraseña debe tener mín. 8 caracteres con letras y números.'; return;
    }
    if (!_auth) { if (errEl) errEl.textContent = 'Sin conexión con Firebase.'; return; }

    setLoading('auth-reg-submit', true);

    try {
        const cred = await createUserWithEmailAndPassword(_auth, email, pw);
        const extra = {
            username,
            bio: localStorage.getItem('profile_bio') || '',
            favoriteGenres: (function() {
                try { return JSON.parse(localStorage.getItem('profile_genres') || '[]'); } catch { return []; }
            })()
        };
        await saveUserProfile(cred.user, extra);
        localStorage.setItem('profile_username', username);
        await sendEmailVerification(cred.user);
        const dispEl = $el('auth-verify-email-display');
        if (dispEl) dispEl.textContent = email;
        showScreen('verify');
    } catch(e) {
        if (errEl) errEl.textContent = authErrorMsg(e.code);
    }
    setLoading('auth-reg-submit', false, 'Crear cuenta');
}

// ── Social login ─────────────────────────────────────────────────────
async function socialLogin(providerName, errElId) {
    if (!_auth) { toast('Sin conexión con Firebase'); return; }
    const errEl    = $el(errElId);
    const provider = providerName === 'google' ? new GoogleAuthProvider() : new GithubAuthProvider();
    provider.setCustomParameters?.({ prompt: 'select_account' });
    try {
        await signInWithPopup(_auth, provider);
        hide();
        clearErrors();
    } catch(e) {
        if (e.code === 'auth/popup-closed-by-user') return;
        const msg = authErrorMsg(e.code);
        if (errEl) errEl.textContent = msg; else toast(msg);
    }
}

// ── Forgot password ──────────────────────────────────────────────────
async function sendReset() {
    const email = $el('auth-reset-email')?.value.trim() || $el('auth-login-email')?.value.trim();
    if (!email || !_auth) { toast('Introduce tu correo electrónico'); return; }
    try {
        await sendPasswordResetEmail(_auth, email);
        toast('✉️ Enlace enviado a ' + email);
        const ff = $el('auth-forgot-form'); if (ff) ff.style.display = 'none';
    } catch(e) { toast(authErrorMsg(e.code)); }
}

async function resendVerification() {
    if (!_auth?.currentUser) return;
    try { await sendEmailVerification(_auth.currentUser); toast('✉️ Correo reenviado'); } catch(_) {}
}

// ── Sign out ─────────────────────────────────────────────────────────
async function signOut() {
    if (!_auth) return;
    try {
        if (_currentUser) {
            await savePreferences(_currentUser.uid);
            await window.UserSync?.saveAll?.();
        }
        await fbSignOut(_auth);
        hide();
        toast('Sesión cerrada');
    } catch(e) { toast('Error al cerrar sesión'); }
}

// ── Error messages ───────────────────────────────────────────────────
function authErrorMsg(code) {
    const map = {
        'auth/user-not-found':          'No existe una cuenta con ese correo.',
        'auth/wrong-password':          'Contraseña incorrecta.',
        'auth/invalid-credential':      'Correo o contraseña incorrectos.',
        'auth/email-already-in-use':    'Ese correo ya está registrado.',
        'auth/invalid-email':           'El correo no es válido.',
        'auth/weak-password':           'Contraseña muy débil.',
        'auth/too-many-requests':       'Demasiados intentos. Espera un momento.',
        'auth/network-request-failed':  'Sin conexión a internet.',
        'auth/account-exists-with-different-credential': 'Ya existe una cuenta con ese correo. Inicia sesión con otro método.',
        'auth/popup-blocked':           'El navegador bloqueó la ventana. Permite ventanas emergentes.',
    };
    return map[code] || 'Ocurrió un error. Intenta de nuevo.';
}

// ── Password validation hints ────────────────────────────────────────
function validatePassword(pw) {
    const lenOk = pw.length >= 8;
    const mixOk = /[a-zA-Z]/.test(pw) && /[0-9]/.test(pw);
    const hintLen = $el('auth-hint-len');
    const hintMix = $el('auth-hint-mix');
    if (hintLen) hintLen.classList.toggle('aform-hint--ok', lenOk);
    if (hintMix) hintMix.classList.toggle('aform-hint--ok', mixOk);
}

// ── Auth state listener ───────────────────────────────────────────────
if (_auth) {
    onAuthStateChanged(_auth, async (user) => {
        _currentUser = user;
        if (user) {
            // Show sync loading overlay immediately
            const overlay = $el('sync-loading-overlay');
            if (overlay) overlay.classList.add('active');
            if (window.AppState) window.AppState.isSyncing = true;

            try {
                // Trigger full cloud sync first
                window.UserSync?.onLogin(user.uid);
                const syncResult = await window.UserSync?.syncDown?.(user.uid);
                _cloudProfile = syncResult?.profile || await loadUserProfile(user);
                const prefs = await loadPreferences(user.uid);
                applyPreferences(prefs);
                updateSettingsCard(user, _cloudProfile);
                Settings_updateStats?.();
            } catch (error) {
                console.warn('[Auth] Sync failed:', error?.message || error);
                // Still load profile and prefs even if sync fails
                _cloudProfile = await loadUserProfile(user);
                const prefs = await loadPreferences(user.uid);
                applyPreferences(prefs);
                updateSettingsCard(user, _cloudProfile);
                Settings_updateStats?.();
            } finally {
                // Hide overlay after sync completes or fails
                if (overlay) overlay.classList.remove('active');
                if (window.AppState) window.AppState.isSyncing = false;
            }
        } else {
            _cloudProfile = null;
            updateSettingsCard(null, null);
            window.UserSync?.onLogout();
            window.Library?.clear?.();
            window.ProfileEditor?.clear?.();
            Settings_updateStats?.();
            // Restore local profile card via ProfileEditor
            window.ProfileEditor?.applyToCard?.();
        }
    });
}

// Expose for script.js Settings.updateProfileStats to call
function Settings_updateStats() {
    const libEl       = $el('cfg-stat-library');
    const watchedEl   = $el('cfg-stat-watched');
    const completedEl = $el('cfg-stat-completed');
    // Still reads from local AppState (values are already in DOM via script.js)
    // Auth just ensures the card header is correct
    // Future: read from RTDB stats here
}

// ── Setup: event listeners ───────────────────────────────────────────
function setup() {
    // ── cfg-edit-profile intercept (capture phase → runs before script.js's handler) ──
    const editBtn = $el('cfg-edit-profile');
    if (editBtn) {
        editBtn.addEventListener('click', e => {
            e.stopImmediatePropagation();
            if (_currentUser) {
                window.ProfileEditor?.open?.();
            } else {
                showScreen('welcome', 'forward');
                show();
            }
        }, true); // capture phase
    }

    // ── Welcome screen ──
    $el('auth-welcome-back')?.addEventListener('click', () => hide());
    $el('auth-to-login')?.addEventListener('click', () => showScreen('login'));
    $el('auth-to-register')?.addEventListener('click', () => showScreen('register'));
    $el('auth-welcome-google')?.addEventListener('click', () => socialLogin('google', null));
    $el('auth-welcome-github')?.addEventListener('click', () => socialLogin('github', null));

    // ── Login screen ──
    $el('auth-login-back')?.addEventListener('click', () => { clearErrors(); showScreen(_prevScreen, 'back'); });
    $el('auth-login-submit')?.addEventListener('click', loginWithEmail);
    $el('auth-login-pw')?.addEventListener('keydown', e => { if (e.key === 'Enter') loginWithEmail(); });
    $el('auth-login-email')?.addEventListener('keydown', e => { if (e.key === 'Enter') $el('auth-login-pw')?.focus(); });
    $el('auth-google-login')?.addEventListener('click', () => socialLogin('google', 'auth-login-error'));
    $el('auth-github-login')?.addEventListener('click', () => socialLogin('github', 'auth-login-error'));
    $el('auth-to-register-from-login')?.addEventListener('click', () => { clearErrors(); showScreen('register'); });
    $el('auth-forgot-link')?.addEventListener('click', () => {
        const ff = $el('auth-forgot-form');
        if (ff) {
            const opening = !ff.classList.contains('aform-forgot-panel--open');
            ff.classList.toggle('aform-forgot-panel--open', opening);
            if (opening) {
                const re = $el('auth-reset-email');
                if (re) re.value = $el('auth-login-email')?.value || '';
                setTimeout(() => re?.focus(), 50);
            }
        }
    });
    $el('auth-reset-send')?.addEventListener('click', sendReset);

    // ── Eye toggles ──
    $el('auth-login-eye')?.addEventListener('click', () => togglePw('auth-login-pw', 'auth-login-eye'));
    $el('auth-reg-eye')?.addEventListener('click',   () => togglePw('auth-reg-pw',   'auth-reg-eye'));

    // ── Register screen ──
    $el('auth-register-back')?.addEventListener('click', () => { clearErrors(); showScreen(_prevScreen, 'back'); });
    $el('auth-reg-submit')?.addEventListener('click', registerWithEmail);
    $el('auth-reg-pw')?.addEventListener('input', e => validatePassword(e.target.value));
    $el('auth-google-register')?.addEventListener('click', () => socialLogin('google', 'auth-reg-error'));
    $el('auth-github-register')?.addEventListener('click', () => socialLogin('github', 'auth-reg-error'));
    $el('auth-to-login-from-register')?.addEventListener('click', () => { clearErrors(); showScreen('login', 'back'); });

    // ── Verify screen ──
    $el('auth-verify-back')?.addEventListener('click', () => { clearErrors(); showScreen('register', 'back'); });
    $el('auth-resend-link')?.addEventListener('click', resendVerification);
    $el('auth-verify-continue')?.addEventListener('click', () => { hide(); clearErrors(); });

    // ── Account screen ──
    $el('auth-account-back')?.addEventListener('click', () => hide());
    $el('auth-account-edit')?.addEventListener('click', () => { hide(); window.ProfileEditor?.open?.(); });
    $el('auth-sign-out')?.addEventListener('click', signOut);

    // ── Profile editor logout button ──
    $el('pe-logout-btn')?.addEventListener('click', () => {
        window.ProfileEditor?.close?.();
        setTimeout(() => signOut(), 340);
    });

    // ── Close on backdrop (welcome screen only) ──
    $el('auth-overlay')?.addEventListener('click', e => {
        if (e.target === $el('auth-overlay') && _currentScreen === 'welcome') hide();
    });
}

function togglePw(inputId, btnId) {
    const inp = $el(inputId);
    const btn = $el(btnId);
    if (!inp) return;
    const shown = inp.type === 'text';
    inp.type = shown ? 'password' : 'text';
    if (btn) btn.innerHTML = shown ? ICON_EYE_OPEN : ICON_EYE_CLOSED;
}

const ICON_EYE_OPEN   = `<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
const ICON_EYE_CLOSED = `<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`;

setup();

// ── AuthManager: public API ───────────────────────────────────────────
const AuthManager = {
    open()            { showScreen('welcome', 'forward'); show(); },
    isAuthenticated() { return !!_currentUser; },
    currentUser()     { return _currentUser; },
    refreshCard()     { updateSettingsCard(_currentUser, _cloudProfile); }
};
window.AuthManager = AuthManager;

// ── AuthHelpers: exposed for other modules ──────────────────────────────
window.AuthHelpers = {
    currentUid:      () => _currentUser?.uid  || null,
    currentUsername: () => {
        const local = localStorage.getItem('profile_username');
        return local || _cloudProfile?.username || _currentUser?.displayName || null;
    },
    currentProfile:  () => _cloudProfile
};

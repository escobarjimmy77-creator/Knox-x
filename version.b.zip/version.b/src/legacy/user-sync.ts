// user-sync.js — AnimeSAO Pro Cloud Sync v2.0
// Mirrors library, history, algorithm, profile and stats to Firebase RTDB.
// Uses localStorage monkey-patching so zero changes to script.js are needed.
// @ts-nocheck

import { getFirebaseApp, getFirebaseDB } from '../services/firebase/index.ts';
import { ref, set, update, get, onValue } from 'firebase/database';

let _app, _db, _uid = null;
let _restoring = false;
const _listeners = [];
const _timers = {};

const STORAGE_KEYS = {
    library: 'anime_library',
    history: 'anime_history',
    algorithm: 'anime_prefs',
    profileUsername: 'profile_username',
    profileBio: 'profile_bio',
    profileGenres: 'profile_genres',
    profilePhoto: 'profile_photo',
    lastSessionTime: 'last_session_time'
};

const GUEST_KEYS = {
    library: 'guest_anime_library',
    history: 'guest_anime_history',
    algorithm: 'guest_anime_prefs',
    profileUsername: 'guest_profile_username',
    profileBio: 'guest_profile_bio',
    profileGenres: 'guest_profile_genres',
    profilePhoto: 'guest_profile_photo'
};

const PROFILE_KEYS = [
    STORAGE_KEYS.profileUsername,
    STORAGE_KEYS.profileBio,
    STORAGE_KEYS.profileGenres,
    STORAGE_KEYS.profilePhoto
];

try {
    _app = getFirebaseApp();
    _db  = getFirebaseDB();
} catch (e) { console.warn('[UserSync] Firebase init:', e.message); }

// ── Helpers ──────────────────────────────────────────────────────────
const fbKey = id => String(id).replace(/[.#$/\[\]]/g, '_');
const parse = key => { try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch { return null; } };

function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function retryWrite(fn, retries = 3, initialDelay = 350) {
    let attempt = 0;
    let delay = initialDelay;
    while (attempt < retries) {
        try {
            return await fn();
        } catch (error) {
            attempt += 1;
            if (attempt >= retries) {
                console.warn('[UserSync] retryWrite failed:', error?.message || error);
                throw error;
            }
            await wait(delay);
            delay *= 2;
        }
    }
}

// ── Guest data migration ──────────────────────────────────────────────
function migrateGuestData() {
    const guestLib = parse(GUEST_KEYS.library) || [];
    const guestHist = parse(GUEST_KEYS.history) || [];
    const guestAlgo = parse(GUEST_KEYS.algorithm) || {};
    const guestUsername = localStorage.getItem(GUEST_KEYS.profileUsername) || '';
    const guestBio = localStorage.getItem(GUEST_KEYS.profileBio) || '';
    const guestGenres = parse(GUEST_KEYS.profileGenres) || [];
    const guestPhoto = localStorage.getItem(GUEST_KEYS.profilePhoto) || '';

    // Migrate to auth keys if not already set
    if (guestLib.length > 0 && !parse(STORAGE_KEYS.library).length) {
        silentSet(STORAGE_KEYS.library, JSON.stringify(guestLib));
        if (window.AppState) window.AppState.library = guestLib;
    }
    if (guestHist.length > 0 && !parse(STORAGE_KEYS.history).length) {
        silentSet(STORAGE_KEYS.history, JSON.stringify(guestHist));
        if (window.AppState) window.AppState.history = guestHist;
    }
    if (Object.keys(guestAlgo).length > 0 && !Object.keys(parse(STORAGE_KEYS.algorithm)).length) {
        silentSet(STORAGE_KEYS.algorithm, JSON.stringify(guestAlgo));
        if (window.AppState) window.AppState.userPreferences = guestAlgo;
    }
    if (guestUsername && !localStorage.getItem(STORAGE_KEYS.profileUsername)) {
        silentSet(STORAGE_KEYS.profileUsername, guestUsername);
    }
    if (guestBio && !localStorage.getItem(STORAGE_KEYS.profileBio)) {
        silentSet(STORAGE_KEYS.profileBio, guestBio);
    }
    if (guestGenres.length > 0 && !parse(STORAGE_KEYS.profileGenres).length) {
        silentSet(STORAGE_KEYS.profileGenres, JSON.stringify(guestGenres));
    }
    if (guestPhoto && !localStorage.getItem(STORAGE_KEYS.profilePhoto)) {
        silentSet(STORAGE_KEYS.profilePhoto, guestPhoto);
    }

    // Clear guest data after migration
    Object.values(GUEST_KEYS).forEach(key => localStorage.removeItem(key));
}

function debounce(key, fn, ms = 1800) {
    clearTimeout(_timers[key]);
    _timers[key] = setTimeout(fn, ms);
}

function normalizeCloudList(value) {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    if (typeof value === 'object') return Object.values(value);
    return [];
}

function getTimestamp(item, timeKey) {
    return Number(item?.[timeKey] ?? item?.updatedAt ?? 0);
}

function stopRealtimeSync() {
    _listeners.forEach(unsub => { try { unsub(); } catch (_) {} });
    _listeners.length = 0;
}

function startRealtimeSync(uid) {
    if (!_db || !uid) return;
    stopRealtimeSync();
    _uid = uid;

    const addListener = (path, callback) => {
        const unsub = onValue(ref(_db, path), snapshot => callback(snapshot.val()));
        _listeners.push(unsub);
    };

    addListener(`users/${uid}/library`, raw => {
        const cloudLib = normalizeCloudList(raw);
        const localLib = parse(STORAGE_KEYS.library) || [];
        const merged   = mergeArrays(localLib, cloudLib, 'id', 'addedAt');
        silentSet(STORAGE_KEYS.library, JSON.stringify(merged));
        if (window.AppState) window.AppState.library = merged;
        window.Library?.render?.();
    });

    addListener(`users/${uid}/history`, raw => {
        const cloudHist = normalizeCloudList(raw);
        const localHist = parse(STORAGE_KEYS.history) || [];
        const merged    = mergeArrays(localHist, cloudHist, 'id', 'watchedAt');
        const sorted    = merged.sort((a, b) => (b.watchedAt || 0) - (a.watchedAt || 0)).slice(0, 100);
        silentSet(STORAGE_KEYS.history, JSON.stringify(sorted));
        if (window.AppState) window.AppState.history = sorted;
        window.Library?.render?.();
    });

    addListener(`users/${uid}/profile`, raw => {
        const profile = raw || {};
        if (profile.username)    silentSet('profile_username', profile.username);
        if (profile.photoURL)    silentSet('profile_photo', profile.photoURL);
        if (profile.email)       silentSet('profile_email', profile.email);
        if (window.ProfileEditor?.applyToCard) window.ProfileEditor.applyToCard();
        if (window.Settings?.updateProfileStats) window.Settings.updateProfileStats();
    });

    addListener(`users/${uid}/profileExtended`, raw => {
        const data = raw || {};
        if (data.username)       silentSet('profile_username', data.username);
        if (data.bio)            silentSet('profile_bio', data.bio);
        if (data.favoriteGenres) silentSet('profile_genres', JSON.stringify(data.favoriteGenres));
        if (data.photoURL)       silentSet('profile_photo', data.photoURL);
        if (window.ProfileEditor?.applyToCard) window.ProfileEditor.applyToCard();
        if (window.Settings?.updateProfileStats) window.Settings.updateProfileStats();
    });

    addListener(`users/${uid}/algorithm`, raw => {
        const cloudAlgo = raw || {};
        if (cloudAlgo.genres) {
            silentSet(STORAGE_KEYS.algorithm, JSON.stringify(cloudAlgo.genres));
            silentSet(STORAGE_KEYS.lastSessionTime, String(cloudAlgo.lastSessionTime || Date.now()));
            if (window.AppState) window.AppState.userPreferences = cloudAlgo.genres;
        }
    });
}

// ── Array merge: prefer the entry with the newer timestamp ───────────
function mergeArrays(local = [], cloud = [], idKey, timeKey) {
    const map = new Map();
    local.forEach(item => map.set(String(item[idKey]), item));
    cloud.forEach(item => {
        const key = String(item[idKey]);
        if (!key) return;
        const cur = map.get(key);
        const cloudTs = getTimestamp(item, timeKey);
        const currentTs = getTimestamp(cur, timeKey);
        if (!cur || cloudTs > currentTs) {
            map.set(key, item);
        }
    });
    return Array.from(map.values());
}

// ── Silent localStorage write (won't re-trigger sync) ────────────────
const _origSet = localStorage.setItem.bind(localStorage);
const _origRemove = localStorage.removeItem.bind(localStorage);
const _origClear = localStorage.clear.bind(localStorage);
const _origGet = localStorage.getItem.bind(localStorage);
function silentSet(key, value) {
    _restoring = true;
    _origSet(key, value);
    _restoring = false;
}

function silentRemove(key) {
    _restoring = true;
    _origRemove(key);
    _restoring = false;
}

// ── Save functions ───────────────────────────────────────────────────
async function saveLibrary() {
    if (!_db || !_uid) return;
    try {
        const raw = parse(STORAGE_KEYS.library) || [];
        const map = {};
        raw.forEach(item => {
            if (!item?.id) return;
            map[fbKey(item.id)] = {
                ...item,
                updatedAt: item.updatedAt || item.addedAt || Date.now()
            };
        });
        await retryWrite(() => set(ref(_db, `users/${_uid}/library`), map));
    } catch (e) { console.warn('[UserSync] saveLibrary:', e?.message || e); }
}

async function saveHistory() {
    if (!_db || !_uid) return;
    try {
        const raw = parse(STORAGE_KEYS.history) || [];
        const map = {};
        raw.forEach(item => {
            if (!item?.id) return;
            map[fbKey(item.id)] = {
                ...item,
                updatedAt: item.updatedAt || item.watchedAt || Date.now()
            };
        });
        await retryWrite(() => set(ref(_db, `users/${_uid}/history`), map));
    } catch (e) { console.warn('[UserSync] saveHistory:', e?.message || e); }
}

async function saveAlgorithm() {
    if (!_db || !_uid) return;
    try {
        const genres = parse(STORAGE_KEYS.algorithm) || {};
        const lastSession = Number(localStorage.getItem(STORAGE_KEYS.lastSessionTime) || Date.now());
        await retryWrite(() => set(ref(_db, `users/${_uid}/algorithm`), {
            genres,
            lastSessionTime: lastSession,
            updatedAt: Date.now()
        }));
    } catch (e) { console.warn('[UserSync] saveAlgorithm:', e?.message || e); }
}

async function saveProfileExtended() {
    if (!_db || !_uid) return;
    try {
        const data = {
            username:       localStorage.getItem(STORAGE_KEYS.profileUsername) || '',
            bio:            localStorage.getItem(STORAGE_KEYS.profileBio)      || '',
            favoriteGenres: parse(STORAGE_KEYS.profileGenres) || [],
            photoURL:       localStorage.getItem(STORAGE_KEYS.profilePhoto)    || '',
            updatedAt:      Date.now()
        };

        await retryWrite(() => set(ref(_db, `users/${_uid}/profileExtended`), data));

        // Keep the main profile node aligned for avatar and username display.
        const profileData = {
            username:  data.username,
            photoURL:  data.photoURL,
            updatedAt: Date.now()
        };
        await retryWrite(() => update(ref(_db, `users/${_uid}/profile`), profileData));
    } catch (e) { console.warn('[UserSync] saveProfileExtended:', e?.message || e); }
}

async function saveStats() {
    if (!_db || !_uid) return;
    try {
        const library = parse(STORAGE_KEYS.library) || [];
        const history = parse(STORAGE_KEYS.history) || [];
        const stats = {
            totalLibrary: library.length,
            watched:      new Set(history.map(h => h.id)).size,
            completed:    library.filter(i => i.status === 'completed').length,
            pending:      library.filter(i => i.status === 'pending').length,
            favorites:    library.filter(i => i.favorite).length,
            updatedAt:    Date.now()
        };
        await retryWrite(() => set(ref(_db, `users/${_uid}/stats`), stats));
    } catch (e) { console.warn('[UserSync] saveStats:', e?.message || e); }
}

// ── Queue a debounced save ───────────────────────────────────────────
function queueSave(type) {
    if (!_uid) return; // No save to cloud for guests
    debounce(type, () => {
        if (type === 'library')   { saveLibrary();   saveStats(); }
        if (type === 'history')   { saveHistory();   saveStats(); }
        if (type === 'algorithm') { saveAlgorithm(); }
        if (type === 'profile')   { saveProfileExtended(); }
    });
}

// ── Pull all cloud data and merge into localStorage + AppState ────────
async function syncDown(uid) {
    if (!_db) return;
    _uid = uid;

    try {
        // Migrate guest data first if needed
        migrateGuestData();

        const results = await Promise.all([
            get(ref(_db, `users/${uid}/library`)).then(snap => {
                const cloudLib = normalizeCloudList(snap.val());
                const localLib = parse(STORAGE_KEYS.library) || [];
                const merged = mergeArrays(localLib, cloudLib, 'id', 'addedAt');
                silentSet(STORAGE_KEYS.library, JSON.stringify(merged));
                if (window.AppState) window.AppState.library = merged;
                return merged;
            }),
            get(ref(_db, `users/${uid}/history`)).then(snap => {
                const cloudHist = normalizeCloudList(snap.val());
                const localHist = parse(STORAGE_KEYS.history) || [];
                const merged = mergeArrays(localHist, cloudHist, 'id', 'watchedAt');
                const sorted = merged.sort((a, b) => (b.watchedAt || 0) - (a.watchedAt || 0)).slice(0, 100);
                silentSet(STORAGE_KEYS.history, JSON.stringify(sorted));
                if (window.AppState) window.AppState.history = sorted;
                return sorted;
            }),
            get(ref(_db, `users/${uid}/algorithm`)).then(snap => {
                const cloudAlgo = snap.val() || {};
                if (cloudAlgo.genres) {
                    silentSet(STORAGE_KEYS.algorithm, JSON.stringify(cloudAlgo.genres));
                    silentSet(STORAGE_KEYS.lastSessionTime, String(cloudAlgo.lastSessionTime || Date.now()));
                    if (window.AppState) window.AppState.userPreferences = cloudAlgo.genres;
                }
                return cloudAlgo.genres;
            }),
            get(ref(_db, `users/${uid}/profileExtended`)).then(snap => {
                const p = snap.val() || {};
                // Clear local if cloud doesn't have it
                if (p.username !== undefined) silentSet(STORAGE_KEYS.profileUsername, p.username || '');
                else silentRemove(STORAGE_KEYS.profileUsername);
                if (p.bio !== undefined) silentSet(STORAGE_KEYS.profileBio, p.bio || '');
                else silentRemove(STORAGE_KEYS.profileBio);
                if (p.favoriteGenres !== undefined) silentSet(STORAGE_KEYS.profileGenres, JSON.stringify(p.favoriteGenres || []));
                else silentRemove(STORAGE_KEYS.profileGenres);
                if (p.photoURL !== undefined) silentSet(STORAGE_KEYS.profilePhoto, p.photoURL || '');
                else silentRemove(STORAGE_KEYS.profilePhoto);
                return p;
            })
        ]);

        // Refresh UI panels if they are open
        window.Library?.render?.();
        window.Settings?.updateProfileStats?.();
        window.ProfileEditor?.applyToCard?.();

        // Emit sync complete event
        window.dispatchEvent(new CustomEvent('userSync:ready', { detail: { uid, results } }));

        return { library: results[0], history: results[1], algorithm: results[2], profile: results[3] };

    } catch (e) {
        console.warn('[UserSync] syncDown error:', e.message);
        // Still emit event even on error, to unblock UI
        window.dispatchEvent(new CustomEvent('userSync:ready', { detail: { uid, error: e.message } }));
        return null;
    }
}

// ── Save everything immediately (e.g. before logout) ─────────────────
async function saveAll() {
    await Promise.all([
        saveLibrary(),
        saveHistory(),
        saveAlgorithm(),
        saveProfileExtended(),
        saveStats()
    ]);
}

// ── Monkey-patch localStorage methods ────────────────────────────────
// Intercepts writes from script.js without touching its source code.
localStorage.setItem = function (key, value) {
    const targetKey = !_uid ? GUEST_KEYS[key] || key : key;
    _origSet(targetKey, value);
    if (_restoring) return;
    if (key === STORAGE_KEYS.library)  queueSave('library');
    if (key === STORAGE_KEYS.history)  queueSave('history');
    if (key === STORAGE_KEYS.algorithm) queueSave('algorithm');
    if (PROFILE_KEYS.includes(key))     queueSave('profile');
};

localStorage.removeItem = function (key) {
    const targetKey = !_uid ? GUEST_KEYS[key] || key : key;
    _origRemove(targetKey);
    if (_restoring) return;
    if (key === STORAGE_KEYS.library)  queueSave('library');
    if (key === STORAGE_KEYS.history)  queueSave('history');
    if (key === STORAGE_KEYS.algorithm) queueSave('algorithm');
    if (PROFILE_KEYS.includes(key))     queueSave('profile');
};

localStorage.clear = function () {
    _origClear();
    if (_restoring) return;
    if (_uid) saveAll().catch(() => {});
};

localStorage.getItem = function (key) {
    const targetKey = !_uid ? GUEST_KEYS[key] || key : key;
    return _origGet(targetKey);
};

window.addEventListener('beforeunload', () => {
    if (_uid) saveAll().catch(() => {});
});

// ── Clear user data on logout ────────────────────────────────────────
function clearUserData() {
    stopRealtimeSync();
    _uid = null;
    
    // Clear all user-specific localStorage keys
    Object.values(STORAGE_KEYS).forEach(key => silentRemove(key));
    
    // Clear AppState
    if (window.AppState) {
        window.AppState.library = [];
        window.AppState.history = [];
        window.AppState.userPreferences = {};
    }
    
    // Clear UI elements
    if (window.ProfileEditor?.clear) window.ProfileEditor.clear();
    if (window.Library?.clear) window.Library.clear();
    if (window.Library?.render) window.Library.render();
    if (window.Settings?.updateProfileStats) window.Settings.updateProfileStats();
}

// ── Public API ──────────────────────────────────────────────────────
window.UserSync = {
    onLogin(uid)  { startRealtimeSync(uid); },
    onLogout()    { clearUserData(); },
    saveAll,
    queueSave,
    syncDown
};

console.log('[UserSync] Cloud sync module ready ✓');

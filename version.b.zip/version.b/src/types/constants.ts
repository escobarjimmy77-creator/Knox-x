/**
 * Constants - Configuración centralizada de la aplicación
 */

// API Configuration
export const API_BASE = "/api";

// Secciones del menú
export const SECTIONS_CONFIG = [
    { id: "latest", title: "Añadidos Recientemente", type: "latest", endpoint: "latest" },
    { id: "trending", title: "Animes Populares", type: "trending", endpoint: "trending" },
    { id: "action", title: "Acción", type: "genre", endpoint: "genre/accion" },
    { id: "comedy", title: "Comedia", type: "genre", endpoint: "genre/comedia" },
    { id: "romance", title: "Romance", type: "genre", endpoint: "genre/romance" },
    { id: "fantasy", title: "Fantasía", type: "genre", endpoint: "genre/fantasia" },
    { id: "isekai", title: "Isekai", type: "genre", endpoint: "genre/isekai" },
    { id: "drama", title: "Drama", type: "genre", endpoint: "genre/drama" },
    { id: "shounen", title: "Shounen", type: "genre", endpoint: "genre/shounen" },
    { id: "mystery", title: "Misterio", type: "genre", endpoint: "genre/misterio" },
];

// Recomendaciones configuración
export const RECOMMENDATION_CONFIG = {
    maxItems: 200,
    maxAge: 90 * 24 * 60 * 60 * 1000,
    genreWeights: { action: 1.5, comedy: 1.2, shounen: 1.4, isekai: 1.3 },
    decayRate: 0.95,
    minScore: 20,
};

// Cache configuración
export const CACHE_CONFIG = {
    duration: 15 * 60 * 1000,
    maxSize: 100,
    cleanup: 10 * 60 * 1000,
};

// UI Configuration
export const UI_CONFIG = {
    debounceDelay: 300,
    animationDuration: 300,
    toastTimeout: 3000,
    loadMoreThreshold: 500,
    itemsPerPage: 24,
};

// SVG Icons
export const ICONS = {
    CHEVRON: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"></polyline></svg>`,
    USER: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`,
};

// Auth Configuration
export const AUTH_SCREENS = {
    HOME: 'home',
    LOGIN: 'login',
    REGISTER: 'register',
    PROFILE: 'profile',
};

// Password validation
export const PASSWORD_RULES = {
    minLength: 8,
    requireUppercase: true,
    requireNumbers: true,
    requireSpecial: true,
};

// Username configuration
export const USERNAME_CONFIG = {
    minLength: 3,
    maxLength: 32,
    pattern: /^[a-zA-Z0-9_-]+$/,
    cooldown: 24 * 60 * 60 * 1000,
};

// Base64 placeholder
export const BLANK_IMAGE_BASE64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';

/**
 * Firebase Configuration (Centralized)
 * Evita duplicación de credenciales entre múltiples archivos
 */

const env = (import.meta as any).env as Record<string, string | undefined>;

function envOrFallback(key: string, fallback: string): string {
    return env[key] || fallback;
}

export const FB_CONFIG = {
    apiKey:           envOrFallback('VITE_FIREBASE_API_KEY', 'AIzaSyCr1bcF_Lc1lKNoTmVYqIduwDqZIxK-mrM'),
    authDomain:       envOrFallback('VITE_FIREBASE_AUTH_DOMAIN', 'cerberusai-87db2.firebaseapp.com'),
    projectId:        envOrFallback('VITE_FIREBASE_PROJECT_ID', 'cerberusai-87db2'),
    storageBucket:    envOrFallback('VITE_FIREBASE_STORAGE_BUCKET', 'cerberusai-87db2.firebasestorage.app'),
    messagingSenderId: envOrFallback('VITE_FIREBASE_MESSAGING_SENDER_ID', '942100846980'),
    appId:            envOrFallback('VITE_FIREBASE_APP_ID', '1:942100846980:web:b1437acb40fc973a0d25d1'),
    databaseURL:      envOrFallback('VITE_FIREBASE_DATABASE_URL', 'https://cerberusai-87db2-default-rtdb.firebaseio.com')
};

export const FB_APP_NAME = envOrFallback('VITE_FIREBASE_APP_NAME', 'animesao-pro');

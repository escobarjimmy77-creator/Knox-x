/**
 * Firebase Service - Inicialización centralizada
 */

import { FB_CONFIG, FB_APP_NAME } from './config';
import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { getDatabase, Database } from 'firebase/database';
import { getAuth, Auth } from 'firebase/auth';

let fbApp: FirebaseApp | null = null;
let fbDatabase: Database | null = null;
let fbAuth: Auth | null = null;

function initFirebase() {
    if (fbApp) return fbApp;

    const existingApps = getApps();
    const existing = existingApps.find(app => app.name === FB_APP_NAME);

    if (existing) {
        fbApp = existing;
    } else {
        fbApp = initializeApp(FB_CONFIG, FB_APP_NAME);
    }

    return fbApp;
}

export function getFirebaseApp(): FirebaseApp {
    if (!fbApp) initFirebase();
    return fbApp as FirebaseApp;
}

export function getFirebaseDB(): Database {
    if (!fbDatabase) {
        const app = getFirebaseApp();
        fbDatabase = getDatabase(app);
    }
    return fbDatabase;
}

export function getFirebaseAuth(): Auth {
    if (!fbAuth) {
        const app = getFirebaseApp();
        fbAuth = getAuth(app);
    }
    return fbAuth;
}

export { FB_CONFIG, FB_APP_NAME } from './config';

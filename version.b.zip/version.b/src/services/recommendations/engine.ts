/**
 * Recommendation Engine - Genera recomendaciones personalizadas
 */

import { RECOMMENDATION_CONFIG } from '../../types/constants';

export interface AnimeScore {
    id: string;
    title: string;
    score: number;
    genres: string[];
    reason?: string;
}

export interface AnimeItem {
    id: string;
    title: string;
    genres: string[];
    lastEpisode?: string;
    [key: string]: any;
}

interface UserProfile {
    watchedIds: Set<string>;
    preferredGenres: Record<string, number>;
    watchHistory: Array<{ id: string; title: string; timestamp: number }>;
}

export class RecommendationEngine {
    private profile: UserProfile = {
        watchedIds: new Set(),
        preferredGenres: {},
        watchHistory: [],
    };

    trackWatch(anime: AnimeItem) {
        if (!anime || !anime.id) return;
        this.profile.watchedIds.add(anime.id);
        this.profile.watchHistory.push({
            id: anime.id,
            title: anime.title,
            timestamp: Date.now(),
        });

        anime.genres.forEach(genre => {
            this.profile.preferredGenres[genre] = (this.profile.preferredGenres[genre] || 0) + 1;
        });
    }

    scoreAnime(anime: AnimeItem): AnimeScore {
        const genreScore = anime.genres.reduce((sum, genre) => {
            return sum + (RECOMMENDATION_CONFIG.genreWeights[genre as keyof typeof RECOMMENDATION_CONFIG.genreWeights] || 1);
        }, 0);

        const watchedPenalty = this.profile.watchedIds.has(anime.id) ? -50 : 0;
        const ageBoost = Math.max(0, RECOMMENDATION_CONFIG.maxAge - (Date.now() - (anime.updatedAt || Date.now())));
        const decay = ageBoost > 0 ? ageBoost / RECOMMENDATION_CONFIG.maxAge : 0;

        const score = Math.max(
            0,
            Math.round((genreScore * 10 + decay * 20 + 10) * RECOMMENDATION_CONFIG.decayRate) + watchedPenalty
        );

        return {
            id: anime.id,
            title: anime.title,
            score,
            genres: anime.genres,
            reason: this.profile.watchedIds.has(anime.id)
                ? 'Ya visto recientemente'
                : 'Géneros similares a tu historial',
        };
    }

    getRanked(items: AnimeItem[]): AnimeScore[] {
        return items
            .map(item => this.scoreAnime(item))
            .filter(entry => entry.score >= RECOMMENDATION_CONFIG.minScore)
            .sort((a, b) => b.score - a.score);
    }

    getSimilar(target: AnimeItem, items: AnimeItem[]): AnimeScore[] {
        return items
            .filter(item => item.id !== target.id)
            .map(item => {
                const sharedGenres = item.genres.filter(genre => target.genres.includes(genre));
                const similarity = sharedGenres.length / Math.max(item.genres.length, target.genres.length, 1);
                return {
                    id: item.id,
                    title: item.title,
                    score: Math.round(similarity * 100),
                    genres: item.genres,
                    reason: `Coinciden ${sharedGenres.length} géneros`,
                };
            })
            .filter(item => item.score > 0)
            .sort((a, b) => b.score - a.score);
    }
}

let instance: RecommendationEngine | null = null;

export function getRecommendationEngine(): RecommendationEngine {
    if (!instance) {
        instance = new RecommendationEngine();
    }
    return instance;
}

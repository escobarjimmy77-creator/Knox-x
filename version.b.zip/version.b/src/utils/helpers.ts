/**
 * Helper Functions - Utilidades centralizadas
 */

export const $ = (selector: string): HTMLElement | null => {
    return document.querySelector(selector);
};

export const esc = (s: string | null | undefined): string => {
    const str = String(s ?? '');
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
};

export const debounce = (
    fn: (...args: any[]) => void,
    delay: number
): ((...args: any[]) => void) => {
    let timeoutId: number | undefined;
    return (...args: any[]) => {
        if (timeoutId !== undefined) {
            window.clearTimeout(timeoutId);
        }
        timeoutId = window.setTimeout(() => fn(...args), delay);
    };
};

export const delay = (ms: number): Promise<void> => {
    return new Promise(resolve => setTimeout(resolve, ms));
};

export const shuffleArray = <T>(arr: T[]): T[] => {
    const copy = [...arr];
    for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
};

export const showToast = (message: string, duration = 3000) => {
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.textContent = message;
    toast.style.position = 'fixed';
    toast.style.bottom = '24px';
    toast.style.left = '50%';
    toast.style.transform = 'translateX(-50%)';
    toast.style.background = 'rgba(0,0,0,0.8)';
    toast.style.color = '#fff';
    toast.style.padding = '12px 18px';
    toast.style.borderRadius = '999px';
    toast.style.zIndex = '9999';
    toast.style.fontSize = '0.95rem';
    toast.style.transition = 'opacity 0.2s ease';
    toast.style.opacity = '0';

    document.body.appendChild(toast);
    requestAnimationFrame(() => {
        toast.style.opacity = '1';
    });

    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 200);
    }, duration);
};

export const normalizeUsername = (username: string): string => {
    return username.toLowerCase().trim();
};

export const safeJsonParse = (json: string, fallback: any = null) => {
    try {
        return JSON.parse(json);
    } catch {
        return fallback;
    }
};

export const fbKey = (id: string | number): string => {
    return String(id).replace(/[.#$\/\[\]]/g, '_');
};

export const mergeArraysByTimestamp = (a: any[], b: any[]): any[] => {
    const merged = [...a, ...b];
    return merged.sort((itemA, itemB) => {
        const timeA = Number(itemA?.updatedAt || itemA?.timestamp || 0);
        const timeB = Number(itemB?.updatedAt || itemB?.timestamp || 0);
        return timeB - timeA;
    });
};

export const formatTimestamp = (ts: number): string => {
    return new Date(ts).toLocaleDateString('es-ES', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
    });
};

export const jaccardSimilarity = (a: string[], b: string[]): number => {
    const setA = new Set(a);
    const setB = new Set(b);
    const intersection = new Set([...setA].filter(x => setB.has(x)));
    const union = new Set([...setA, ...setB]);
    return union.size === 0 ? 0 : intersection.size / union.size;
};

export class ElementCache {
    private cache = new Map<string, HTMLElement | null>();

    get(selector: string): HTMLElement | null {
        if (this.cache.has(selector)) {
            return this.cache.get(selector) || null;
        }
        const element = document.querySelector<HTMLElement>(selector);
        this.cache.set(selector, element);
        return element;
    }

    clear(): void {
        this.cache.clear();
    }
}

export const elemCache = new ElementCache();

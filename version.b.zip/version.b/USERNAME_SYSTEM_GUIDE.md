# Sistema de Usernames Únicos en la Nube ☁️

## Diagrama del Sistema Mejorado

```
┌─────────────────────────────────────────────────────────────────┐
│                        USUARIO                                   │
├─────────────────────────────────────────────────────────────────┤
│  1. Ingresa nombre: "Mi Usuario"                                 │
│  2. Sistema normaliza: "mi_usuario"                              │
│  3. Se envía a Firebase                                          │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                  FIREBASE REALTIME DB                             │
├─────────────────────────────────────────────────────────────────┤
│  usernames/                                                      │
│    ├── mi_usuario/                                               │
│    │   ├── uid: "user-id-xyz"  ◄─── BUSCAS AQUÍ                 │
│    │   └── reservedAt: 1234567890                                │
│    └── otro_usuario/                                             │
│        ├── uid: "user-id-abc"                                    │
│        └── reservedAt: 1234567890                                │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
        ┌──────────────────────────────┐
        │   ¿NOMBRE ENCONTRADO?        │
        └──────────┬───────────────────┘
                   │
         ┌─────────┴──────────┬─────────────┐
         ▼                    ▼              ▼
      SI (Existe)        NO (No existe) NO RESPONDE
      "❌ En Uso"        "✅ Disponible" "(?) Error conexión"
         │                     │              │
         ▼                     ▼              ▼
    Error al             Continuar      Reintentar o
    guardar              registro       verificar wifi
```

## Estados Posibles (Tripartición)

```typescript
checkUsernameAvailable(username) → ?

┌─────────────────────────────────────────────────────────────┐
│ RETORNO          │ SIGNIFICA              │ USUARIO VE      │
├─────────────────────────────────────────────────────────────┤
│ true             │ ✅ Disponible          │ Continuar →     │
│                  │ Listo para usar        │                 │
├─────────────────────────────────────────────────────────────┤
│ false            │ ❌ En Uso              │ "Ya está en    │
│                  │ Otro usuario lo tiene  │ uso. Elige     │
│                  │                        │ otro."          │
├─────────────────────────────────────────────────────────────┤
│ null             │ ⚠️  No se pudo         │ "No se puede   │
│                  │ verificar ERROR DB     │ verificar.     │
│                  │ Conexión rota          │ Revisa wifi"    │
└─────────────────────────────────────────────────────────────┘
```

## Flujo Completo: Registro

```
Usuario abre app
       │
       ▼
    ┌─────────────────────────────────┐
    │ Pantalla de Registro            │
    │ [Mi Usuario XYZ]                │
    └─────────────────────────────────┘
       │
       ▼ Presiona "Crear Cuenta"
    ┌─────────────────────────────────┐
    │ 1️⃣  VALIDACIÓN LOCAL             │
    │ ¿Tiene 3-32 caracteres?         │
    │ ¿Solo caracteres válidos?       │
    └─────────────────────────────────┘
       │
       ├→ NO ❌  → "Username inválido"
       │
       └→ SÍ ✅  → Siguiente
            │
            ▼
    ┌─────────────────────────────────┐
    │ 2️⃣  NORMALIZACIÓN               │
    │ "Mi Usuario XYZ" → "mi_usuario" │
    └─────────────────────────────────┘
       │
       ▼ Se conecta a Firebase
    ┌─────────────────────────────────┐
    │ 3️⃣  CONSULTA FIREBASE RTDB       │
    │ ¿Existe usernames/mi_usuario?   │
    └─────────────────────────────────┘
       │
       ├─→ ERROR ⚠️  "Revisa conexión"
       │
       ├─→ SÍ EXISTE ❌  "Ya en uso"
       │
       └─→ NO EXISTE ✅  → Siguiente
            │
            ▼
    ┌─────────────────────────────────┐
    │ 4️⃣  CREAR USUARIO EN AUTH        │
    │ Email: usuario@email.com        │
    │ Contraseña: ••••••••            │
    └─────────────────────────────────┘
       │
       ▼ Se crea en Firebase Auth
    ┌─────────────────────────────────┐
    │ 5️⃣  RESERVAR NOMBRE               │
    │ Guardar en usernames/mi_usuario │
    │ con UID del usuario             │
    └─────────────────────────────────┘
       │
       ├→ ERROR ⚠️  "Error al guardar"
       │
       └→ ÉXITO ✅  → Siguiente
            │
            ▼
    ┌─────────────────────────────────┐
    │ 6️⃣  ENVIAR EMAIL VERIFICACIÓN   │
    │ Verifica: usuario@email.com     │
    └─────────────────────────────────┘
       │
       ▼
    ┌─────────────────────────────────┐
    │ ✅ REGISTRO EXITOSO             │
    │ Cuenta creada y lista           │
    └─────────────────────────────────┘
```

## Flujo Completo: Cambio de Username

```
Usuario autenticado
       │
       ▼
    ┌─────────────────────────────────┐
    │ Pantalla de Perfil              │
    │ Nombre: "viejo_nombre"          │
    │ [nuevo_nombre] [Guardar]        │
    └─────────────────────────────────┘
       │
       ▼ Presiona "Guardar"
    ┌─────────────────────────────────┐
    │ 1️⃣  VERIFICAR COOLDOWN           │
    │ ¿Pasaron 7 días desde último?   │
    └─────────────────────────────────┘
       │
       ├→ NO ❌  "Puedes cambiar en X días"
       │
       └→ SÍ ✅  → Siguiente
            │
            ▼
    ┌─────────────────────────────────┐
    │ 2️⃣  VERIFICAR DISPONIBILIDAD     │
    │ ¿Existe nuevo_nombre en DB?     │
    │ (O ¿es mío actual?)             │
    └─────────────────────────────────┘
       │
       ├─→ ERROR ⚠️  "Revisa conexión"
       │
       ├─→ EN USO ❌  "Ya en uso"
       │
       └─→ DISPONIBLE ✅  → Siguiente
            │
            ▼
    ┌─────────────────────────────────┐
    │ 3️⃣  ACTUALIZAR EN DB             │
    │ Remover: viejo_nombre           │
    │ Agregar: nuevo_nombre           │
    └─────────────────────────────────┘
       │
       ▼
    ┌─────────────────────────────────┐
    │ 4️⃣  GUARDAR TIMESTAMP CAMBIO    │
    │ lastUsernameChange = Ahora      │
    └─────────────────────────────────┘
       │
       ▼
    ┌─────────────────────────────────┐
    │ ✅ CAMBIO EXITOSO               │
    │ Nombre actualizado en nube       │
    └─────────────────────────────────┘
```

## Estructura en Firebase

```
{
  "users": {
    "user-id-xyz": {
      "profile": {
        "username": "mi_usuario",
        "displayName": "Mi Usuario",
        "lastUsernameChange": 1714982400000
      }
    }
  },
  "usernames": {
    "mi_usuario": {
      "uid": "user-id-xyz",
      "reservedAt": 1714982400000
    },
    "otro_usuario": {
      "uid": "user-id-abc",
      "reservedAt": 1714982400001
    }
  }
}
```

## Normalización: De Nombre a ID

```
INPUT              →  TRANSFORMACIÓN              → OUTPUT (ID)
────────────────────────────────────────────────────────────────
"Mi Usuario"       →  minúsculas                  → "mi usuario"
                   →  espacios a _                → "mi_usuario"
                   →  ✓ válido (9 chars)          → "mi_usuario"

"Juan@123!"        →  minúsculas                  → "juan@123!"
                   →  quita caracteres especiales → "juan123"
                   →  ✓ válido (7 chars)          → "juan123"

"A-B.C_D"          →  minúsculas                  → "a-b.c_d"
                   →  caracteres válidos          → "a-b.c_d"
                   →  ✓ válido (7 chars)          → "a-b.c_d"

"ab"               →  minúsculas                  → "ab"
                   →  ✗ muy corto (<3)            → INVÁLIDO

"UsuarioConNombre  →  minúsculas                  → "......"
MuyMuyMuyLargo..."  →  demasiado (>32)            → INVÁLIDO
```

## Características del Sistema

✅ **Almacenamiento único en la nube**
- Base de datos: Firebase Realtime Database
- Ruta: `/usernames/`
- Backup y sincronización automática

✅ **Validación en 2 niveles**
- Local: formato y longitud
- Cloud: unicidad global

✅ **Tripartición de errores**
- Disponible (true)
- En uso (false)  
- Error de conexión (null)

✅ **Cooldown de 7 días**
- Previene cambios frecuentes
- Resguarda contra vandalismo

✅ **Logging detallado**
- Ver en consola (F12)
- [Auth] logs para debugging
- Timestamps con cada acción

✅ **Información rica en DB**
- UID del dueño
- Timestamp de reserva
- Historial potencial

## Cómo Usar (Desarrollador)

```javascript
// Verificar disponibilidad exacta
const info = await window.AuthHelpers.getUsernameInfo('miusuario', 'current-uid');
// → {exists: boolean, uid: string|null, isOwner: boolean}

// Verificación simple (recomendado para UI)
const available = await window.AuthHelpers.checkUsernameAvailable('miusuario');
// → true (disponible) | false (en uso) | null (error)

// Para debugging
window.AuthHelpers.currentUid()
window.AuthHelpers.currentUsername()
```

## Resolución de Problemas

| Problema | Causa Probable | Solución |
|----------|---|---|
| "Todos en uso" | RTDB desconectada | Verifica wifi y credenciales |
| "Ya en uso" pero no existe | Datos residuales | Limpiar Firebase console |
| Cambio no se guarda | Permisos RTDB | Verificar security rules |
| Verificación lenta | Lag de conexión | Esperar o reintentar |
| Consola vacía | Logs deshabilitados | F12 → Console → actualizar |

---

**Versión:** 1.0  
**Última actualización:** 6 May 2026  
**Status:** ✅ Producción

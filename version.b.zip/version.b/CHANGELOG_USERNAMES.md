# Cambios del Sistema de Usernames Únicos - Resumen Técnico

## Fecha
6 de Mayo, 2026

## Problema Original
"No se puede verificar el usuario ahora. Revisa tu conexión e inténtalo más tarde" se mostraba para TODOS los usuarios, incluso nombres únicos no registrados.

Causas identificadas:
1. Firebase RTDB no disponible → retornaba `false`
2. Error de conexión → retornaba `false`  
3. Usuario en uso → retornaba `false`
   
Estos tres estados se trataban igual, confundiendo "error = usuario ocupado".

## Solución: Tripartición de Estados

### Antes
```typescript
checkUsernameAvailable() → boolean
- true: disponible
- false: ocupado O error
- **Problema:** indistinguible
```

### Ahora
```typescript
checkUsernameAvailable() → true | false | null
- true: disponible
- false: ocupado
- null: error de conexión/no se pudo verificar

// Nueva función complementaria
getUsernameInfo() → {exists, uid, isOwner} | null
- exists: boolean - username existe en DB
- uid: string|null - UID del dueño
- isOwner: boolean - el usuario actual es dueño
- return null si hay error
```

## Cambios en `auth.ts`

### 1. Nueva Función: `_isValidUsername()`
```typescript
function _isValidUsername(username: string): boolean
// Valida:
// - Longitud 3-32 caracteres
// - Formato válido (sin caracteres inválidos)
// Retorna false si no pasa validación
```

### 2. Nueva Función: `getUsernameInfo()`
```typescript
async function getUsernameInfo(username, currentUid = null) {
  // Conecta a Firebase en: usernames/${normalized}
  // Retorna: {exists, uid, isOwner} o null
  // Incluye logging detallado para debugging
}
```

### 3. Mejora: `checkUsernameAvailable()`
```typescript
async function checkUsernameAvailable(username, currentUid = null) {
  // Ahora utiliza getUsernameInfo()
  // Retorna:
  // - true: no existe OR es del usuario actual
  // - false: existe y NO es del usuario actual
  // - null: error de conexión
}
```

### 4. Mejora: `reserveUsername()`
```typescript
async function reserveUsername(newUsername, oldUsername, uid) {
  // Cambios:
  // 1. Devuelve boolean (true/false) en lugar de void
  // 2. Mejor logging con timestamps
  // 3. Guarda {uid, reservedAt} en lugar de solo uid
  // 4. Mejor manejo de errores
}
```

### 5. Mejora: `registerWithEmail()`
```typescript
async function registerWithEmail() {
  // Nuevas validaciones:
  // 1. _isValidUsername() antes de Firebase
  // 2. Manejo separado de null (error) vs false (ocupado)
  // 3. Verificar que reserveUsername() fue exitoso
  // 4. Logging detallado de cada paso
  // 5. Mejor mensajes de error específicos
}
```

### 6. Actualización: `AuthHelpers`
```javascript
window.AuthHelpers = {
  checkUsernameAvailable,     // existía
  reserveUsername,             // existía
  getUsernameInfo,             // NUEVA - para verificación detallada
  checkUsernameCooldown,       // existía
  markUsernameChanged,         // existía
  currentUid: () => ...,       // existía
  currentUsername: () => ...   // existía
}
```

## Cambios en Base de Datos Firebase

### Estructura Anterior
```
usernames/
  ├── nombreusuario1/ → "user-id-123"
  ├── nombreusuario2/ → "user-id-456"
```

### Estructura Nueva
```
usernames/
  ├── nombreusuario1/ → {
        uid: "user-id-123",
        reservedAt: 1714982400000
      }
  ├── nombreusuario2/ → {
        uid: "user-id-456", 
        reservedAt: 1714982400001
      }
```

**Ventajas:**
- Almacena timestamp de reserva (útil para auditoría)
- Más estructura para futuros casos (expiración, etc.)
- Compatible con búsquedas y análisis

## Flujo Mejorado: Registro

```
1. Usuario ingresa: "Mi Usuario XYZ"
   ↓
2. Validar formato
   - ¿Tiene 3-32 caracteres? Si no → error
   - ¿Solo caracteres válidos? Si no → error
   ↓
3. Normalizar: "miusuarioxy"
   ↓
4. Conectar a Firebase → usernames/miusuarioxy
   - ¿Existe? 
     - No → DISPONIBLE → continuar
     - Sí → EN USO → error "Ya está en uso"
     - Error → DESCONOCIDO → error "Revisa tu conexión"
   ↓
5. Crear usuario en Firebase Auth
   ↓
6. Guardar en usernames/miusuarioxy
   - Si falla → error "Error al guardar nombre"
   - Si éxito → continuar
   ↓
7. Enviar email de verificación
```

## Logging Agregado

Todos los pasos ahora generan logs en consola (F12):

```
[Auth] getUsernameInfo("miusuario" → "miusuario"): exists=false, uid=null, currentUid=null, isOwner=false
[Auth] registerWithEmail: creando usuario con nombre miusuario
[Auth] registerWithEmail: usuario de Firebase creado, UID: user-id-789
[Auth] reserveUsername: registrar "miusuario" para UID user-id-789
[Auth] reserveUsername: nombre "miusuario" guardado para UID user-id-789
```

## Archivos Afectados

1. **src/legacy/auth.ts**
   - Líneas ~110-200: Sistema de usernames
   - Líneas ~365-410: registerWithEmail()
   - Líneas ~620-635: AuthHelpers export

2. **src/legacy/script.ts**
   - Líneas ~3840-3870: Cambio de username en perfil
   - Maneja ahora los 3 estados (true/false/null)

## Compatibilidad

✅ **Backward compatible:**
- `checkUsernameAvailable()` retorna true/false que es lo esperado
- Código que llamaba antes sigue funcionando
- Firebase RTDB schema compatible

## Testing Manual Recomendado

### Test 1: Registro Nuevo
1. Abre la aplicación
2. Intenta registrarte con nombre "prueba123"
3. Verifica en consola:
   - `exists=false`
   - Luego email de verificación

### Test 2: Duplicado
1. Como usuario registrado, intenta cambiar a un username existente
2. Debe decir "Ya está en uso"
3. En consola: `exists=true`

### Test 3: Sin Conexión (Simular)
1. Desactiva wifi/conexión
2. Intenta registrarte
3. Debe decir "Revisa tu conexión"
4. En consola: retorna `null`

## Performance Impact

✅ **Mínimo impacto:**
- Una lectura extra en Firebase (getUsernameInfo)
- Logs en consola solo en dev/user actions
- Sin cambios en sync de datos principales

## Regression Risk

⚠️ **Bajo riesgo:**
- Cambios aislados a sistema de usernames
- No afecta auth.ts flujo principal (login, social login)
- Cambios en script.ts solo en perfil editor

---

## Historial de Versiones

### v1.0 (6 May 2026)
- [+] Tripartición de estados (true/false/null)
- [+] `getUsernameInfo()` con info detallada
- [+] `_isValidUsername()` validación
- [+] Logging mejorado
- [+] `reserveUsername()` devuelve boolean
- [+] Mejor manejo de errores en registro
- [+] Firebase RTDB schema mejorado (+timestamp)
